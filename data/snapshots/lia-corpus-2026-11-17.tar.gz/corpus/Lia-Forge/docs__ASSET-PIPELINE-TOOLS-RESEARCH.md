# ASSET-PIPELINE-TOOLS-RESEARCH — Pipelines, formatos, conversões e produção de assets

**Data:** 2026-11-14 (UTC) · **Branch:** `arena/6113e868-lia-forge` · **Estado:** RESEARCH — **não autoriza instalação, execução, custo ou adoção**.

**Escopo:** pipelines de assets 2D/3D; formatos (FBX, glTF/GLB, USD, KTX2, Draco); conversão e otimização; validadores; spritesheets; texturização; produção de conteúdo audiovisual (Remotion); combinação de ferramentas; IA para geração de assets (com ressalvas).

**Relacionados:** [`ANIMATION-TOOLS-RESEARCH.md`](ANIMATION-TOOLS-RESEARCH.md) · [`3D-RENDERING-TOOLS-RESEARCH.md`](3D-RENDERING-TOOLS-RESEARCH.md) · [`BLENDER-MCP-RESEARCH.md`](BLENDER-MCP-RESEARCH.md) · [`COLIBRI-TECHNICAL-RESEARCH.md`](COLIBRI-TECHNICAL-RESEARCH.md) · [`TOOLS-COMPARISON-MATRIX.md`](TOOLS-COMPARISON-MATRIX.md) · [`auditoria-blender-local/`](auditoria-blender-local/README.md) · especificação de contratos (existe apenas na branch T13 `5b0ec51`: `DOMAIN-CONTRACTS-IMPLEMENTATION-SPEC.md`).

**Convenções:** **F** fato verificado (GitHub API/npm/PyPI/fetch 2026-11-14) · **I** inferência · **H** hipótese.

---

## 1. Resumo executivo

- O pipeline da Forge tem **5 estágios já decididos** pela pesquisa anterior: **GLB canônico** como intercâmbio → **Blender headless first-party** como produtor → **three.js** como inspeção → **QA determinístico próprio** → **pacote com proveniência**. Este documento avalia as peças ao redor (conversão, otimização, validação, empacotamento, vídeo, texturas).
- **F** Otimização/conversão glTF tem opções maduras e grátis (Cesium `gltf-pipeline` Apache-2.0; `glTF-Transform` MIT; `meshoptimizer` MIT) — não há razão técnica para ferramenta paga aqui.
- **F** AO **contratar Remotion**, a licença é gratuita só para indivíduos/empresas com **até 3 pessoas**; acima disso, Company License (Creators US$25/mês por seat; Automators US$0,01/render, mín. US$100/mês; Enterprise ≥ US$500/mês — preços vistos em `remotion.dev/pricing`, 2026-11-14). A Forge é uma empresa de porte desconhecido → **portão humano + decisão de orçamento** antes de qualquer adoção.
- **F** Spritesheets: `free-tex-packer` (MIT) é a melhor opção gratuita; `TexturePacker` (comercial) e `Aseprite` (fonte pública, não-OSI) são pagas; `LibreSprite` (GPL-2.0) é o fork livre.
- **IA gen de assets (Meshy/Tripo/Rodin/Hunyuan…):** licenciamento de saída e ToS de cada provedor são o bloqueio real — **não adotar sem autorização explícita, revisão de licença e política de dados**.

## 2. Formatos e intercâmbio

| Formato | Papel na Forge | Notas |
|---|---|---|
| **glTF 2.0 / GLB** | **Canônico** | Cenas PBR, animações, morph/skin; JSON+binário (GLB) autocontido; validado por Khronos |
| **FBX** | Ingresso apenas (legado/Mixamo/marketplaces) | Proprietário Autodesk; converter para GLB na entrada e arquivar o FBX original |
| **USD / USDZ** | Não usar como intercâmbio interno agora | Ecossistema Apple/Pixar; pista futura p/ cenas grandes (H, P3) |
| **OBJ/MTL** | Ingresso legado | Sem animações/PBR real — só malha estática |
| **PNG/WebP/AVIF/KTX2** | Texturas | PNG lossless p/ authored; KTX2/Basis p/ GPU (ETC1S/UASTC) — exige transcoder |
| **JSON de atlas** (Pixi/Phaser/JSON-array/hash) | Spritesheets | Contrato próprio recomendado (§5) |
| **`.riv` / Lottie JSON / `.lottie`** | UI animada | Ver ANIMATION-TOOLS-RESEARCH |

**Regra:** nenhum formato entra "cru" no projeto; tudo normalizado para GLB + texturas KTX2/PNG na ingestão, com hash e licença registrados no envelope.

## 3. Conversão e otimização de modelos

| Ferramenta | Licença | Stars · push | Função | Classe · P |
|---|---|---|---|---|
| **Blender headless (bpy)** | GPL-3.0 (interopera com Blender) | — | Import FBX/OBJ/glTF → limpeza → GLB; o conversor universal | RECOMMENDED · P0 (já é o caminho 5b0ec51) |
| **CesiumGS/gltf-pipeline** | Apache-2.0 | 2,1 mil · 2026-06-23 | Draco, quantization, resize/otimização de texturas | RECOMMENDED · P1 |
| **DonMcCurdy/glTF-Transform** (`@gltf-transform/*@4.5.1`) | MIT | 2,1 mil · 2026-10-20 | CLI + API: inspect/validate/optimize/convert/texcompress (toktx) | RECOMMENDED · P1 |
| **zeux/meshoptimizer** (`gltfpack`) | MIT | 8,9 mil · 2026-10-14 | Otimização agressiva (vertex cache, overdraw, simplificação) | RECOMMENDED · P1/P2 |
| **Shopify/gltf-compressor** | MIT | 360 · 2026-05 | Alternativa de compressão | ALTERNATIVE · P2 |
| **KhronosGroup/KTX-Software** | **NOASSERTION** (mix; verificar `LICENSE.txt` — contém Apache-2.0 + outros) | 1,4 mil · 2026-11-10 | `toktx`/`ktx` CLI — KTX2/UASTC/ETC1S | RECOMMENDED c/ revisão · P1 |
| **google/draco** (`draco3d@1.5.9`) | Apache-2.0 | 7,6 mil · 2026-11-14 | Draco compres/decompress standalone | ALTERNATIVE (gltf-pipeline já usa) · P2 |
| **facebookincubator/FBX2glTF** | **NOASSERTION** (licença não identificada pela API) | 2,4 mil · 2026-03-27 | FBX→glTF direto (sem Blender) | RESEARCH-ONLY · P3 — preferir Blender; se usar, fixar versão e ler LICENSE |
| **KhronosGroup/glTF-Validator** (`gltf-validator`) | Apache-2.0 | 482 · 2026-10-06 | Validador CLI/JS — **portão de qualidade automatizável** | RECOMMENDED · P0/P1 |
| **KhronosGroup/glTF-Compressor** | **NOASSERTION** | 83 · 2026-10-06 | Experimental; skip | RESEARCH-ONLY · P3 |

**Pipeline recomendado (determinístico, sem rede):**

```
FBX/OBJ/glTF bruto
   │  (staging + hash)
   ▼
Blender headless ──► GLB limpo (transforms aplicados, materiais PBR,
   │                             normais recalculadas, escala 1u = 1m)
   ▼
glTF-Transform / gltf-pipeline ──► draco/meshopt + KTX2 (opcional no entregável)
   ▼
glTF-Validator ──► JSON de relatório
   ▼
QA Forge (contratos próprios: destino mobile/desktop, polycount, tamanho)
   ▼
Envelope de proveniência → aprovação humana
```

**Fato de operação:** `gltfpack` e `gltf-pipeline` rodam offline, sem custo, em CPU — adequados a qualquer máquina da Forge, inclusive RX 580.

## 4. Texturização e materiais

| Ferramenta | Licença | Status (2026-11-14) | Papel | Classe · P |
|---|---|---|---|---|
| **Material Maker** (`RodZill4/material-maker`) | MIT (API GitHub) | 6,3 mil stars · ativo | Texturas PBR procedurais (ruído, padrões) — terreno/props/rocha | RECOMMENDED p/ props · P2 |
| **Substance 3D Painter/Designer** (Adobe) | Comercial | — | Padrão de indústria (characters/props painted) | ALTERNATIVE pago — custo desconhecido · P2 |
| **Poly Haven** (polyhaven.com) | **CC0** | — | HDRIs/texturas/modelos de referência — uso comercial ok | RECOMMENDED (sob demanda) · P2 |
| **AmbientCG** (ambientcg.com) | **CC0** | — | Texturas tileable CC0 | RECOMMENDED · P2 |
| Blender bake first-party | GPL | — | Bake de normal/AO/rough a partir de high-poly | RECOMMENDED · P1 |
| **Dream Textures** etc. (IA local) | variadas; pesos não comerciais comuns | auditado antes nesta série | **Rejeitado** para o alvo RX 580 | NOT-RECOMMENDED |

**Cuidados:** (1) texturas "CC0" não eliminam a obrigação de registrar origem no envelope; (2) mapas 4K/8K explodem tamanho — KTX2/UASTC + limites por perfil de destino; (3) baking em Polaris = CPU — orçar tempo.

## 5. Spritesheets e atlases

**Fluxo 3D→spritesheet (detalhe em [`BLENDER-MCP-RESEARCH.md`](BLENDER-MCP-RESEARCH.md) e [`3D-RENDERING-TOOLS-RESEARCH.md`](3D-RENDERING-TOOLS-RESEARCH.md) §5):** Blender headless (orto, film_transparent, EEVEE) → PNG seq com alpha → **pack** → JSON de atlas → QA → envelope.

| Ferramenta | Licença | Status | Papel | Classe · P |
|---|---|---|---|---|
| **free-tex-packer** (`odrick/free-tex-packer`) | MIT | 1,3 mil stars · app push 2024-07; **core** `free-tex-packer-core@2026-09` ativo; Electron app + CLI | Atlas packer gratuito; formatos hash/array (Pixi/Phaser); trim/rotated frames | RECOMMENDED · P1 |
| Empacotador **first-party** (Node, zero-dep) | Proprietário da Forge | — | Contrato próprio de atlas + envelope + naming + hashing desde o frame 0 | RECOMMENDED (construir) · P1 |
| **TexturePacker** (CodeAndWeb) | Comercial (~US$ 30–60) | — | Packer premium (extrude, smart folders, polygon trim) | ALTERNATIVE — custo/autorização · P2 |
| **Aseprite** | **Não-OSI** (EULA; fonte pública p/ build pessoal) | 41 mil stars · ativo | Editor 2D + CLI export de spritesheet (`aseprite -b file.ase --sheet …`) | ALTERNATIVE pago · P2 — não distribuir builds; comprar seats |
| **LibreSprite** | GPL-2.0 | 8,8 mil stars · ativo | Fork livre do Aseprite antigo | ALTERNATIVE · P2 |
| **Shoebox** (renderhjs) | Grátis (doação) | abandonware | Packer legado | RESEARCH-ONLY · P3 |
| **Zwoptex** (macOS) | Comercial | — | Atlas p/ Mac | RESEARCH-ONLY · P3 |

**Decisão prática:** implementar o empacotador first-party **se** o contrato de atlas da Forge incluir metadados que ferramentas de mercado não emitem (proveniência, hash por frame, perfil de destino, licenças). Caso contrário, `free-tex-packer` como provider opcional — sempre atrás de adapter, nunca como dependência de runtime.

**Formatos de atlas:** recomendar **JSON próprio estendido** (inspirado no "JSON hash" do TexturePacker/Pixi) com campos extras (`provenance`, `sha256` por frame, `pipeline`, `sourceGlb`); engines gerados consomem via loader mínimo — a Forge não amarra o resultado ao Phaser/Pixi.

## 6. Remotion — composição e render audiovisual programático

| Critério | Situação (2026-11-14) |
|---|---|
| Função | Vídeo programático em React; templates parametrizáveis; render server-side via headless Chromium; Lambda p/ escala (AWS — custos à parte) |
| Maturidade | Estável: `remotion@4.0.543` (2026-11-11); 73,5 mil stars; muito ativo |
| Licença | **Não-OSI** — "Remotion License" (source-available). **Grátis** para indivíduos e empresas com **≤ 3 pessoas** (qualquer uso, inclusive comercial); **Company License** acima disso (Creators: US$25/mês/seat; Automators: US$0,01/render, mín. US$100/mês; Enterprise: ≥ US$500/mês; Enterprise inclui Editor Starter). Página de pricing fetched 2026-11-14; termos em `LICENSE.md` |
| Custo | De grátis a US$500+/mês conforme porte — **decisão humana obrigatória** |
| Tecnologia | React + headless Chromium ("Chrome for Testing", ~120 MB baixado no primeiro render) |
| Hardware p/ render | CPU-bound (Chromium); **RX 580 ok**; RAM 16 GB suficiente p/ 1080p moderado; 4K/altos frames = lento; GPU **não** acelera decodificação de forma garantida |
| Integração | CLI/Node SSR API; Lambda; Studio (editor visual) |
| Automação por agentes | Alta (código React determinístico); templates podem ser gerados por agentes — com revisão |
| Limitações | Fonte não-OSI; download de Chrome em runtime; render longo; não é compositor de efeitos (não substitui Blender); custo de licença conforme porte |
| Papel na Forge | Vídeos de showcase de assets, demos parametrizáveis, marketing, changelogs em vídeo — **pós-produção**, não QA |
| Classe · P | **EXPERIMENTAL** (decisão de porte/licença) · P2 |

**Alternativas gratuitas/MIT:**

| Ferramenta | Licença | Status | Papel |
|---|---|---|---|
| **Revideo** (`midrender/revideo`, antes `redotvideo/revideo`) | MIT | 4,2 mil stars · push 2026-07-15 | Fork comunitário do Remotion; render programático; menos docs/suporte |
| **Motion Canvas** (`motion-canvas/motion-canvas`) | MIT | 20 mil stars · push 2026-07-02 | Animações/vídeos em TS com timeline+scenes; ótimo p/ explainers técnicos; sem React |
| **Blender VSE + EEVEE** | GPL | — | Composição de clips/títulos/exportação de showcases — dentro do pipeline já aceito |
| **FFmpeg** (build LGPL/GPL) | LGPL-2.1+/GPL | — | Conversão/mux/normalização de áudio-vídeo; licença depende do build e dos codecs |

**Leitura:** para vídeo de assets, **Blender** cobre 80% (títulos via Freestyle/annotations + VSE). Remotion só se justifica com padrão de "vídeo parametrizado em lote" (ex.: 500 vídeos de personagens com stats diferentes) **e** decisão humana de porte/licença. Caso contrário: **Motion Canvas** (MIT) teste interno.

## 7. IA para geração de assets — panorama com ressalvas

| Caminho | Custo/licença (2026-11-14) | Riscos | Postura |
|---|---|---|---|
| Meshy / Tripo / Hyper3D Rodin / Hunyuan3D via `mcp-for-blender` ou API direta | Créditos/planos pagos; ToS próprios; assets do plano free geralmente com atribuição/não-comercial | IP incerto da saída; dependência de serviço; exfiltração de briefs; sem garantia de topologia/rig | NOT-RECOMMENDED sem autorização explícita |
| Scenario (`scenario-labs/blender-plugin`, GPL-3.0) | SaaS pago | GPL no plugin; serviço fechado | NOT-RECOMMENDED s/ contrato |
| Modelos locais (Dream Textures, HairDeck etc.) | Grátis, mas pesos não-comerciais | Licença de pesos + sem aceleração no RX 580 | Rejeitados em auditorias anteriores |
| Poly Pizza / Sketchfab (busca+download) | Várias (CC0/CC-BY/RF/pagos) | Licença por asset; exige curadoria e registro | RESEARCH-ONLY com ledger de licenças |
| **Poly Haven / AmbientCG** (CC0) | Grátis | Baixo — registrar origem mesmo assim | RECOMMENDED (§4) |

Nenhum fluxo de IA entra em pipeline sem: (1) autorização de custo; (2) licença de saída registrada; (3) QA determinístico; (4) aprovação humana.

## 8. Contratos e proveniência (cola entre ferramentas)

A Forge já possui especificação de envelope (branch T13 `5b0ec51`: `DOMAIN-CONTRACTS-IMPLEMENTATION-SPEC.md`; resumida em [`AGENT-SKILLS-MCP-IMPLEMENTATION-ASSESSMENT.md`](AGENT-SKILLS-MCP-IMPLEMENTATION-ASSESSMENT.md) §5). Para pipeline de assets, estender (PROPOSED):

- `source`: arquivo de origem + sha256; `tool`: nome+versão do conversor/packer; `license`: SPDX/nome da licença do asset **e** do toolchain; `profile`: perfil de destino (mobile/desktop/web); `qa`: relatórios (gltf-validator JSON, contagens); `reviewer`: humano responsável.
- **Toda** ferramenta do pipeline escreve no envelope — nunca "confie, funciona".

## 9. Comparações e combinações

**Remotion vs render em tempo real (three.js):** Remotion = vídeo **offline**, determinístico por frame, custo de render; three.js = **tempo real**, interativo, sem artefato MP4. Não concorrem: three.js p/ preview/interação; Remotion p/ entregável de vídeo — se e somente se porte/licença autorizar.

**Lottie vs spritesheet para personagem:** Lottie p/ UI e ilustração vetorial interativa-leve; spritesheet p/ gameplay com frames discretos, compatível com qualquer engine; não misturar como entrega única.

**gltf-transform vs gltf-pipeline vs gltfpack:** gltf-transform = canivete (inspect+optimize+toktx numa API JS só); gltf-pipeline = Draco/quantização maduro (Cesium, usado em produção massiva); gltfpack = máximo de compressão (simplificação). **Combinação típica:** gltf-transform (normalize) → gltfpack (opcional) → validator (gate).

**Combinação de produção recomendada (P0):** Blender headless → gltf-transform → glTF-Validator → QA Forge → free-tex-packer/first-party → envelope → revisão humana. **Zero custo, zero rede, zero LLM.**

## 10. Classificação consolidada

| Ferramenta | Classe | P |
|---|---|---|
| Blender headless + bpy first-party | RECOMMENDED | P0 |
| glTF-Validator (gate) | RECOMMENDED | P0/P1 |
| glTF-Transform | RECOMMENDED | P1 |
| gltf-pipeline / gltfpack / meshoptimizer | RECOMMENDED | P1/P2 |
| KTX-Software (toktx) — revisão de licença | RECOMMENDED c/ revisão | P1 |
| free-tex-packer | RECOMMENDED | P1 |
| Empacotador first-party de atlas | RECOMMENDED (construir) | P1 |
| Material Maker | RECOMMENDED (props) | P2 |
| Poly Haven / AmbientCG (CC0, registrar) | RECOMMENDED | P2 |
| Remotion | EXPERIMENTAL (porte/licença) | P2 |
| Motion Canvas / Revideo | ALTERNATIVE | P2/P3 |
| TexturePacker / Aseprite | ALTERNATIVE pago | P2 |
| LibreSprite | ALTERNATIVE | P2 |
| FBX2glTF | RESEARCH-ONLY | P3 |
| IA gen 3D (Meshy/Tripo/Rodin/Hunyuan/Scenario) | NOT-RECOMMENDED s/ autorização | — |
| Dream Textures / pesos não-comerciais | NOT-RECOMMENDED | — |

## 11. Fontes

- GitHub API (2026-11-14): `CesiumGS/gltf-pipeline`, `DonMcCurdy/glTF-Transform`, `zeux/meshoptimizer`, `KhronosGroup/glTF-Validator`, `KhronosGroup/KTX-Software`, `KhronosGroup/glTF-Compressor`, `google/draco`, `facebookincubator/FBX2glTF`, `Shopify/gltf-compressor`, `odrick/free-tex-packer(+core/cli)`, `RodZill4/material-maker`, `remotion-dev/remotion`, `midrender/revideo`, `motion-canvas/motion-canvas`, `LibreSprite/LibreSprite`, `aseprite/aseprite`, `EsotericSoftware/spine-runtimes`.
- npm (2026-11-14): `@gltf-transform/core@4.5.1`, `meshoptimizer@1.3.0`, `draco3d@1.5.9`, `remotion@4.0.543` / `@remotion/cli@4.0.543`.
- Fetch primário (2026-11-14): https://www.remotion.dev/pricing (Free ≤3 pessoas; Creators US$25/seat/mês; Automators US$0,01/render mín. US$100/mês; Enterprise US$500+/mês).
- Repositório: auditorias anteriores (`auditoria-blender-local/`, `ECOSYSTEM-RESEARCH-BLENDER-ADDONS.md` rejeitando pesos não-comerciais/CUDA).
- Remotion license (secundário, 2026-07): rendercomp.com, iconpolls.com, reactvideoeditor.com — consistentes com a página primária.
