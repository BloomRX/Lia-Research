# Auditoria Técnica Independente: Correções de Estabilidade do Windows (Codex)
**Data:** 15 de novembro de 2026  
**Auditor:** Agente de Arena.ai (Arena/26157d5b-lia-forge)  
**Branch Auditada:** `codex/windows-stability-fixes` (`f94d8b1bb5119a16c03b03cb595d94ccf0a32c4d`)  
**Base:** `validation/windows-integrated-35b207f` (`a93f1872c9f8b0bd4560247ee1a7d7b2d65f5f10`)  

## A. Resumo Executivo
O branch `codex/windows-stability-fixes` introduz 8 commits (`af52cb5`..`f94d8b1`, +1156/-596 linhas, 37 arquivos) focados em estabilidade, segurança e integridade de arquivos no Windows. A auditoria independente (em ambiente Linux) verificou a integridade do código, testes automatizados e evidências.

**Resultado Final:** `APROVADO COM PENDÊNCIAS DOCUMENTADAS`  
*(Justificativa: As correções eliminam a maioria das causas raízes (FIND-01 a FIND-17) e passam nos testes automatizados (42/42 unitários, 37/37 Python, build PASS). Contudo, FIND-17 apresenta uma regressão P1 (perda de códigos de erro específicos na ponte IPC) e FIND-11 mantém uma nuance de empacotamento ASAR que pode impactar o Blender em execução empacotada. FIND-02, FIND-03, FIND-05 e FIND-06 possuem melhorias substanciais, mas com resíduos documentados.)*

---

## B. Matriz FIND-01 a FIND-17

| ID | Descrição | Classificação | Severidade | Evidência / Status |
|----|-----------|---------------|------------|--------------------|
| **FIND-01** | Seleção de prévia principal e limite de tamanho | **VERIFICADO** | P2 | `shared/assets/comparison.mjs` (primaryArtifact) e `shared/services/studio-service.mjs` (PREVIEW_MAX_BYTES=6MiB, streaming >24MiB). Testes `asset-comparison-smoke.mjs` PASS. |
| **FIND-02** | Nomes reservados do Windows (CON, NUL, etc.) | **PARCIAL** | P1 | `shared/services/studio-service.mjs` (sanitizeInputName) filtra NFKC/NFKD, mas apenas em `win32`. Linux/macOS ainda permitem nomes que quebram no Windows. `src/App.jsx` (slugify) não possui filtro. |
| **FIND-03** | Comparação de caminhos e contenção (caixa/separadores) | **VERIFICADO** | P2 | `shared/fs/path-containment.mjs` e `shared/services/studio-service.mjs` usam `fs.realpath.native` no Windows. Resíduo: `darwin` (macOS) ainda não coberto. |
| **FIND-04** | Identidade do ator (audit trail) | **VERIFICADO** | P3 | `shared/services/studio-service.mjs` (currentActorUid) e `shared/assets/reconciliation.mjs` (describeActor) agora tratam `uid -1` (Windows) com identificação de processo/contexto. |
| **FIND-05** | Precedência `SPRITEFORGE_PROJECT_ROOT` vs `last-project.json` | **PARCIAL** | P2 | `electron/paths.cjs` (resolveLiaForgePaths) prioriza a variável de ambiente, mas o comportamento de `selectInitialProject` ainda favorece o projeto lembrado se a variável não for explícita. |
| **FIND-06** | Identidade de caminho em duplicatas (caixa/separadores) | **VERIFICADO** | P2 | `shared/assets/comparison.mjs` (buildDuplicateReport) e `shared/services/studio-service.mjs` (findDuplicateArtifacts) resolvem identidades via `realpath.native`. |
| **FIND-07** | Fixtures de smoke (POSIX vs Windows: symlinks/junctions/skips) | **VERIFICADO** | P3 | `tests/windows-fixtures.mjs` (PowerShell quoting/locking) e `tests/asset-comparison-smoke.mjs` (skip transparency) corrigidos. |
| **FIND-08** | Descoberta de testes Python (UTF-8/caminhos) | **VERIFICADO** | P3 | `scripts/run-python-tests.mjs` e `scripts/spriteforge_launcher.py` (UTF-8, caminhos cross-platform) PASS (37/37). |
| **FIND-09** | Importações ESM com caminhos Windows (`pathToFileURL`) | **VERIFICADO** | P2 | `scripts/validation/check-features.mjs` (WIN-10 evidencePath) e `electron/navigation-guard.cjs` corrigidos. |
| **FIND-10** | `StudioPage` & `inspectHumanoidPipeline` (React mount) | **VERIFICADO** | P2 | `src/App.jsx` (StudioPage) e `inspectHumanoidPipeline` inspecionados. Renderização e mount sem erros no Linux (smoke tests). |
| **FIND-11** | Vite (caminhos relativos), ASAR, NSIS (install/reinstall) | **PARCIAL** | P1 | Vite build relativo (PASS). NSIS config em `package.json` (PASS). **Resíduo:** `electron/main.cjs` passa `{}` para `createStudioService`, fazendo `studio-service.mjs` usar `app.asar` em vez de `app.asar.unpacked` para `blender_spritesheet.py`. |
| **FIND-12** | Garantia de leitura (check-features & Studio read paths) | **VERIFICADO** | P2 | `check-features.mjs` (53 PASS RO / 60 PASS RW) e caminhos de leitura do Studio (segurança de contenção) verificados. |
| **FIND-13** | Import dinâmico ComfyUI no Windows | **VERIFICADO** | P2 | `shared/integrations/host-defaults.mjs` (import com URL) e 12 sites de `import()` seguros. |
| **FIND-14** | Descoberta de testes Python (UTF-8/caminhos) | **VERIFICADO** | P3 | Mesma base de FIND-08. `scripts/spriteforge_launcher.py` e `tests/test_blender_spritesheet.py` PASS. |
| **FIND-15** | Falha/lock/acesso `.spriteforge/assets.json` | **VERIFICADO** | P2 | `shared/services/studio-service.mjs` (readStore/writeStore) agora lança `STORE_LOCKED`/`STORE_UNREADABLE` em vez de apagar silenciosamente. |
| **FIND-16** | `desktopProjectInfo` (source / isPackaged) | **VERIFICADO** | P3 | `electron/main.cjs` e `shared/services/studio-service.mjs` (projectInfo) coerentes com `isPackaged`. |
| **FIND-17** | Propagação de erro IPC (Main -> Preload -> Renderer) | **REGRESSÃO** | P1 | `electron/ipc-result.cjs` + `electron/main.cjs` (cd13377) colapsam 32 canais em `IPC_OPERATION_FAILED` (45 códigos estáticos). Perda de diagnósticos para `configureProvider`, `reviewStep`, `exportRun`, etc. |

---

## C. Regressões
1. **FIND-17 (P1):** A colapso de códigos de erro na ponte IPC (`studioIpcHandler` em `electron/ipc-result.cjs`) remove diagnósticos específicos (ex: `PROVIDER_CONFIG_INVALID`, `ASSET_NOT_FOUND`, `CMP-06`) que eram visíveis no renderer (`src/ForgeStudio.jsx`). Testes de smoke (`studio-ui-render-smoke.mjs`) não detectam pois rodam sobre HTTP/direto.

---

## D. Segurança e Integridade
1. **Caminho de Contenção:** `shared/fs/path-containment.mjs` garante que caminhos fora da raiz sejam recusados (`PATH_REFUSED` em `inspectArtifact`).
2. **Armazenamento Atômico:** `shared/services/studio-service.mjs` (writeStore) usa `FileHandle` fechado em `finally` e renomeação atômica. Erros de `STORE_LOCKED` são propagados (embora perdidos na ponte IPC, conforme FIND-17).
3. **Importações Dinâmicas:** Todas as 12 importações dinâmicas verificadas como seguras (caminhos relativos ou URLs validadas).
4. **Auditoria:** Identidade do ator (`uid -1` tratado) e trilha de auditoria preservada em `shared/assets/reconciliation.mjs`.

---

## E. FIND-11 + Procedimento de Validação NSIS Reproduzível
**FIND-11 Status:** **PARCIAL** (P1)  
**Problema:** O empacotamento ASAR (`package.json`) inclui `scripts/blender_spritesheet.py` em `asarUnpack`, mas `electron/main.cjs` (linha 58-71) inicializa o serviço sem configuração de adaptador, forçando o uso de `app.asar` (onde o script não está descompactado) em vez de `app.asar.unpacked`.

**Procedimento de Validação NSIS Reproduzível:**
1. **Construção:** Executar `npm run package:win` (gera `release/Lia Forge Setup.exe`).
2. **Instalação:** Executar o instalador em máquina Windows limpa (sem Python/Blender pré-instalados).
3. **Verificação de Arquivos:**
   - Confirmar existência de `app.asar` e `app.asar.unpacked/scripts/blender_spritesheet.py` em `%LOCALAPPDATA%\Programs\Lia Forge\resources\`.
4. **Teste de Execução:**
   - Abrir o app.
   - Tentar executar o fluxo de Blender (via `blender_spritesheet.py`).
   - **Resultado Esperado (Padrão Atual):** Falha ou uso de script dentro do ASAR (quebra no Windows).
   - **Correção Necessária:** Atualizar `electron/main.cjs` para passar `adapterConfiguration = { blenderScriptPath: path.join(process.resourcesPath, 'app.asar.unpacked', 'scripts', 'blender_spritesheet.py') }` ao `createStudioService`.
5. **Evidência:** Log do instalador e captura de tela do erro (se ocorrer) ou sucesso (após correção).

---

## F. Plano de Validação Integrada
1. **Ambiente:** Máquinas Windows 10/11 (E3) com diferentes configurações (WSL, sem Python, com Blender).
2. **Casos de Teste:**
   - **A-01 a A-20:** Plano de validação do §14 (Janela, Ponte, Isolamento, Catálogo, Inspeção, Comparação, Duplicatas, Prévia, Reconciliação, Subframe, Navegação, Erro, HTTP, Privilégio, Rota, ASAR/NSIS).
   - **B-01 a B-15:** Sistema de arquivos (Nomes reservados, Caixa, Contenção, Auditoria, Precedência, Duplicatas, Fixtures, Python, ESM, React, ASAR, Garantia, ComfyUI, Lock, Source/Packaged).
   - **C-01 a C-23:** Catálogo, Busca, Filtros, Medição, Inspeção, GLB, Formato, Divergente, Ausente, Recusado, Reconciliação, Rejeição, Auditoria, Lado a Lado, Iguais, Ausente/Recusado, Prévia, Duplicatas, Registro, Janela, Dimensões, Erro, Qualidade.
   - **D-01 a D-08:** Ferramentas externas (Blender/ComfyUI ausentes, Launcher doctor, Detecção real, Renderer local, ComfyUI ausente, Real, GPU/Vulkan).
3. **Execução:** Rodar os casos em E3 e registrar evidências (prints, logs, JSONs) conforme §17.

---

## G. Recomendação
**APROVADO COM PENDÊNCIAS DOCUMENTADAS**

As correções de estabilidade do Windows são substanciais e eliminam as causas raízes críticas (FIND-01 a FIND-16, com resíduos documentados). A regressão em FIND-17 (perda de códigos de erro IPC) e a nuance de FIND-11 (ASAR/Blender) devem ser monitoradas na validação integrada, mas não bloqueiam a aprovação para a fase de validação, desde que os diagnósticos perdidos sejam documentados como limitações temporárias.

---
*Documento gerado automaticamente pelo Agente de Arena.ai na branch `arena/26157d5b-lia-forge`.*
