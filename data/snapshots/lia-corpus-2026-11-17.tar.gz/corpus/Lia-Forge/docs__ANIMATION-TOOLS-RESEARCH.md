# ANIMATION-TOOLS-RESEARCH — Bibliotecas e sistemas de animação para a Lia Forge

**Data da pesquisa:** 2026-11-14 (UTC) · **Branch:** `arena/6113e868-lia-forge` · **Estado:** RESEARCH / planejamento — **não autoriza implementação, instalação, adoção, custo ou licença**.

**Escopo:** animação 2D de interface, microinterações, transições, timelines, animação por eventos/estados, personagens e elementos visuais, easing/física, performance em desktop (Electron), integração com Vue, Electron, Canvas e SVG.

**Método:** metadados de repositórios via GitHub API (`gh api`), versões via `registry.npmjs.org`, páginas de licença oficiais e `web_search`/`fetch_page` quando o site estava acessível. Tudo marcado como **F** (fato verificado nesta data), **I** (inferência) ou **H** (hipótese). Nada foi instalado, executado ou importado.

**Documentos relacionados:** [`3D-RENDERING-TOOLS-RESEARCH.md`](3D-RENDERING-TOOLS-RESEARCH.md) · [`BLENDER-MCP-RESEARCH.md`](BLENDER-MCP-RESEARCH.md) · [`ASSET-PIPELINE-TOOLS-RESEARCH.md`](ASSET-PIPELINE-TOOLS-RESEARCH.md) · [`TOOLS-COMPARISON-MATRIX.md`](TOOLS-COMPARISON-MATRIX.md) · [`LIA-FORGE-TOOLS-RECOMMENDATIONS.md`](LIA-FORGE-TOOLS-RECOMMENDATIONS.md) · três.js já estudado em [`threejs-3d-environment/`](threejs-3d-environment/README.md) · agentes em [`T14-AGENT-ECOSYSTEM-RESEARCH.md`](T14-AGENT-ECOSYSTEM-RESEARCH.md).

---

## 1. Resumo executivo

- **F** Não existe "biblioteca certa" única: as três grandes (anime.js, Motion, GSAP) resolvem 80% do mesmo problema com licenças, modelos de API e focos diferentes. A escolha é por **camada** (cromo do editor vs. runtime de jogo vs. playback de assets vetoriais), não por gosto.
- **F — achado de licença importante (GSAP):** desde 2025-04-30 o GSAP é grátis para uso comercial, inclusive plugins antes pagos — **mas** a Standard "No Charge" License da Webflow proíbe usar GSAP para criar **ferramentas visuais de construção de animação sem código que concorram com o Webflow**. Um módulo "Lia Animation" do tipo editor visual de timelines embutindo GSAP pode cair nessa cláusula. Uso no cromo da interface (transições, microinterações, feedback de UI) é permitido; o ponto exige parecer jurídico humano antes de qualquer decisão.
- **F** Motion (ex-Framer Motion) é o único com suporte de primeira classe a React **e** Vue e é MIT puro — menor risco jurídico.
- **F** Lottie/dotLottie é a rota madura para **reproduzir** animações vetoriais autoradas por designer (After Effects/Bodymovin), não para autorá-las.
- **F** Rive é a rota para animação 2D **interativa** com state machines; runtimes MIT, editor proprietário na nuvem (custos do editor não verificados nesta pesquisa).
- **Recomendação central:** cromo do editor → Motion (ou GSAP com parecer jurídico); consumo de animações vetoriais de designers → dotLottie; nada disso entra como dependência de runtime dos jogos gerados pela Forge sem decisão humana.

## 2. Notas de evidência

| Fonte | Acesso em 2026-11-14 | Confiabilidade |
|---|---|---|
| GitHub API (licença SPDX, stars, `pushed_at`, `archived`) | OK | Alta para metadados; não prova qualidade |
| npm registry (versão, licença, `time.modified`) | OK | Alta para versões publicadas |
| `gsap.com/community/standard-license/` (via fetch_page) | OK | **Fonte primária da licença GSAP** |
| `remotion.dev/pricing` (via fetch_page) | OK | Fonte primária Remotion (ver doc de pipeline) |
| `animejs.com` (fetch_page) | **Falha HTTP 500** — dados do anime.js vêm de npm/GitHub/libhunt/Hysenlabs | Média para detalhes de API v4 |
| Releases/changelogs de cada repo | Parcial | Verificar na adoção |

Nenhum número de downloads foi medido (a API `api.npmjs.org` está fora do alcance permitido; stars ≠ popularidade de uso real).

## 3. Fichas técnicas

### 3.1 Anime.js — `juliangarnier/anime`

| Critério | Situação (2026-11-14) |
|---|---|
| Função | Engine de animação JS leve (DOM, CSS, SVG, objetos JS, timelines, stagger, springs) |
| Maturidade | Estável. Linha **v4** (ES modules, named exports, breaking changes vs v3: guia de migração oficial); npm `animejs@4.5.0`, publicado 2026-11-02 |
| Licença | **MIT** (SPDX + npm) |
| Custo | Gratuito |
| Tecnologia | TypeScript/JS, zero dependências de runtime declaradas no pacote; runtime `dist` apenas no npm |
| Integração | API JS + timeline; integrável a qualquer framework (sem bindings oficiais Vue/React de primeira classe — usar via refs/lifecycle) |
| Compatibilidade | Windows/Linux/macOS (browser/Chromium/Electron); sem GPU própria — anima via JS/WAAPI + compositor |
| Performance | Excelente para microinterações; v4 elevou fps máx. para 240; usa WAAPI quando possível (I) |
| Automação por agentes | Baixa como ferramenta; alta como **alvo de geração de código** (API previsível, determinística) |
| Limitações | v3→v4 quebra; docs menos completas que GSAP; sem state machines; sem editor |
| Manutenção | Ativa: repo push 2026-11-02, ~74,8 mil stars, 23 releases |
| Aplicação na Lia Forge | Cromo do editor, transições, feedback; timelines simples geradas por agentes |
| Classe / Prioridade | **RECOMMENDED** · P1 |

### 3.2 Motion — `motiondivision/motion` (ex-Framer Motion)

| Critério | Situação |
|---|---|
| Função | Animação para JavaScript vanilla, **React** (`motion/react`) e **Vue** (`motion-v`); gestures, springs, layout animations, scroll-linked, timelines |
| Maturidade | Estável. npm `motion@14.14.0` (2026-11-13). Renomeado de Framer Motion → Motion; `framer-motion` legado |
| Licença | **MIT** (SPDX + npm) |
| Custo | Gratuito (existe camada **Motion+** paga para componentes/extras — não necessária para o núcleo) |
| Tecnologia | TS; engine híbrida JS + WAAPI/Native APIs (120 fps, GPU-acelerada) |
| Integração | React 19, Vue 3 (`motion-v@2.12.0`, MIT), vanilla JS; tree-shakable |
| Compatibilidade | Desktop/Electron; evergreen browsers; Vue 3 ok |
| Performance | Muito boa; WAAPI offload quando possível; springs no main thread quando necessário |
| Automação por agentes | Alta (JSX/TS determinístico); alvo natural para geração de código de UI |
| Limitações | Layout animations são React-first; API React ≠ API vanilla 1:1; não é ferramenta de conteúdo (sem editor, sem AE) |
| Manutenção | Muito ativa: push 2026-11-16, ~35,2 mil stars |
| Aplicação na Lia Forge | Primeira escolha para cromo/animação de interface em Electron+React (T13 usa React em `src/App.jsx`) |
| Classe / Prioridade | **RECOMMENDED** · P1 |

### 3.3 GSAP — `greensock/GSAP`

| Critério | Situação |
|---|---|
| Função | Plataforma de animação web completa: core + ScrollTrigger, Flip, Draggable, SplitText, MorphSVG, DrawSVG, MotionPath… |
| Maturidade | Estável e ubíquo. npm `gsap@3.15.1` (2026-11-11); ~30,7 mil stars; push 2026-11-04 |
| Licença | **NÃO-OSI** — "Standard 'no charge' license" da Webflow (vigente 2025-04-30, rev. 2025-05-30). Grátis p/ uso comercial inclusive plugins; **proíbe** criar com GSAP ferramentas visuais de animação sem código que concorram com o Webflow; Webflow ToS incorporado; não redistribuível como MIT; Webflow pode revisar termos |
| Custo | Gratuito (no-charge), sujeito a restrições acima |
| Tecnologia | JS/TS, sem dependências |
| Integração | Qualquer framework (vanilla; `@gsap/react` hook; sem Vue oficial, mas funciona); plugins como pacotes |
| Compatibilidade | Universal (browser/Electron); alta taxa de sucesso em animações complexas/SVG |
| Performance | Excelente; pipelines maduros; `will-change`/transform batches; controle de fps |
| Automação por agentes | Alta (API documentada); mas **risco de uso proibido** se a saída virar construtor visual concorrente |
| Limitações | Licença não-OSI + cláusula competitiva (ver §4.3); plugins MorphSVG/DrawSVG só fazem sentido p/ design vetorial — verificar caso a caso |
| Manutenção | Ativa; aquisição pela Webflow (2024-10) e liberação total (2025-04-30) aumentam longevidade, mas amarram ao rumo Webflow |
| Aplicação na Lia Forge | Cromo/marketing/demos internas **com parecer jurídico**; **não** embutir em módulo construtor-visual-de-animações sem consentimento escrito da Webflow |
| Classe / Prioridade | **EXPERIMENTAL** (uso interno UI) · P2 — **NOT-RECOMMENDED** dentro de editor visual de animação concorrente do Webflow |

### 3.4 Lottie — `airbnb/lottie-web` e sucessor `LottieFiles/dotlottie-web`

| Critério | Situação |
|---|---|
| Função | **Reproduzir** animações vetoriais exportadas do After Effects (Bodymovin → JSON) ou `.lottie` (ThorVG); playback determinístico com marcadores |
| Maturidade | Estável. `lottie-web@5.13.0` (2025-05-21), repo push 2025-09-01, 32,5 mil stars — ritmo lento, não arquivado; ecossistema migrando para **dotLottie** (`@lottiefiles/dotlottie-web@0.83.2`, MIT, push 2026-11-16; formato `.lottie` + WebAssembly ThorVG + theming) |
| Licença | **MIT** (ambos) |
| Custo | Gratuito (player). Serviços LottieFiles (hosting/analytics) são SaaS à parte — não necessários |
| Tecnologia | JS + SVG/Canvas/WebGL renderer; dotLottie usa WASM (ThorVG) |
| Integração | Qualquer framework; bodymovin plugin gratuito no After Effects |
| Compatibilidade | Windows/Electron ok; SVG renderer = DOM pesado p/ cenas grandes (usar canvas/WASM) |
| Performance | Boa p/ animações vetoriais médias; rasteriza em runtime; não indicada p/ milhares de instâncias — usar sprites/atlas |
| Automação por agentes | Média — agentes podem **selecionar/parametizar** lotties e ajustar cores/markers; não autoram a animação em si |
| Limitações | Não cria; depende de pipeline AE/Bodymovin ou ferramentas (Lottie Creator, Iconscout etc.); JSON pode ser grande; interatividade limitada a segmentos/markers |
| Manutenção | lottie-web mantida em ritmo lento; dotlottie ativo |
| Aplicação na Lia Forge | Playback de animações de personagem/UI entregues por design; previews; onboarding/marketing; runtime de jogos gerados (vetorial leve) |
| Classe / Prioridade | **RECOMMENDED** (dotLottie como preferência; lottie-web como compat) · P1 |

### 3.5 Rive — `rive-app/rive-runtime` (+ editores/SaaS)

| Critério | Situação |
|---|---|
| Função | Animação 2D interativa com **state machines** (inputs, blend states, listeners); formato `.riv`; runtimes C++/JS |
| Maturidade | Runtime maduro; npm `@rive-app/canvas@2.50.0` (2026-11-09), `@rive-app/react-canvas@4.39.0` (MIT); runtime repo 1,3 mil stars, push 2026-11-16 |
| Licença | Runtimes **MIT**; **editor é proprietário** (rive.app, free tier; preços/planos não verificados — site fora do alcance desta pesquisa); `.riv` runtime livre para distribuir |
| Custo | Runtimes grátis; editor free tier (limites desconhecidos) / planos pagos (desconhecidos) |
| Tecnologia | C++ core → WASM/JS; data binding; vector renderer |
| Integração | Web/Electron, React, nativo; formatos de exportação p/ engines (Unity etc. via runtimes) |
| Compatibilidade | Desktop GL ok (canvas/WebGL); Vulkan não é alvo — é 2D |
| Performance | Excelente p/ UI interativa animada (personagens reativos, menus) |
| Automação por agentes | Baixa (autorar `.riv` exige o editor); alta para **integrar** artboards já autoradas |
| Limitações | Vendor: fluxo de autorar depende do SaaS; formato binário próprio; curva de state machine; auditoria de arquivo `.riv` ausente |
| Manutenção | Ativa |
| Aplicação na Lia Forge | Personagens 2D interativos em experiências geradas; UI reativa; alternativa a spritesheets para 2D com poucos frames lógicos |
| Classe / Prioridade | **EXPERIMENTAL** · P2 (editor e custos precisam de decisão humana) |

### 3.6 Ferramentas de jogo/2D relacionadas (contextuais)

| Ferramenta | Licença | Stars / status | Papel | Classe |
|---|---|---|---|---|
| PixiJS (`pixijs/pixijs`) `8.23.0` | MIT | 48,7 mil · ativo | Renderer 2D WebGL/WebGPU batch; base de jogos 2D leves e visualização de atlases | ALTERNATIVE (P2) |
| Phaser (`phaserjs/phaser`) `4.2.1` | MIT | 40,7 mil · ativo (2026-07) | Framework de jogo 2D completo (Canvas/WebGL); excesso para a Forge (é engine, não lib de UI) | RESEARCH-ONLY (P3) |
| DragonBonesJS | MIT | 863 · dormant (push 2026-01) | Esqueletal 2D open source; ecossistema estagnado | RESEARCH-ONLY (P3) |
| Spine runtimes (`EsotericSoftware/spine-runtimes`) | **Licença proprietária** — distribuição exige licença Spine do integrador ou do usuário final | 5,4 mil · ativo | Esqueletal 2D padrão de mercado | NOT-RECOMMENDED p/ distribuir sem compra (P3 se decisão humana de compra) |
| LibreSprite | GPL-2.0 | 8,8 mil · ativo | Editor de sprites gratuito (fork do Aseprite antigo) | ALTERNATIVE ao Aseprite (P2) |
| Aseprite | **Não-OSI** (EULA; fonte pública) | 41 mil · ativo | Editor de sprites; CLI export `--batch` para spritesheets | ALTERNATIVE pago (P2) |
| Inochi2D / Live2D Cubism | LGPL/proprietário | — | Puppets 2D ao vivo | RESEARCH-ONLY (P3) |

> **Spritesheets** (embalar frames em atlas) estão detalhados em [`ASSET-PIPELINE-TOOLS-RESEARCH.md`](ASSET-PIPELINE-TOOLS-RESEARCH.md) §5.

## 4. Comparações concretas

### 4.1 Anime.js vs Motion vs GSAP

| | Anime.js v4 | Motion 14 | GSAP 3.15 |
|---|---|---|---|
| Licença | MIT | MIT | Não-OSI (no-charge; cláusula competitiva) |
| API | `animate()`, timelines, stagger, WAAPI/rAF | `motion.div` React/Vue + `animate()` vanilla | `gsap.to/timeline`, plugins |
| Springs | Nativo (v4) | Nativo; física 1ª classe | Via InertiaPlugin (agora grátis)/custom eases |
| Layout/FLIP | Manual | **Nativo (layout)** | Flip plugin |
| Scroll | Via scroll adapter/utils | Nativo (`useScroll`/scroll()) | ScrollTrigger (referência do gênero) |
| SVG morph | Não (utils básicos) | Não | **MorphSVG** |
| Vue | Via refs (sem binding oficial) | **Oficial (`motion-v`)** | Vanilla ok; sem binding oficial |
| Tamanho bem `npm install` | ~? KB (dist; small) | Tree-shakable | Core pequeno + plugins à la carte |
| Risco jurídico | Nulo | Nulo | **Cláusula competitiva (§4.3)** |
| Melhor para | Timelines imperativas leves, geração de código | Apps React/Vue; gestures; layout | Sequências complexas/SVG/scrub; demos |

**Leitura:** são complementares em força, concorrentes em escopo. Num Electron+React (base T13), Motion cobre o caso de uso com menor atrito e zero risco de licença; Anime.js é o plano B framework-agnóstico e o mais "determinístico" para geração por agentes; GSAP é o mais poderoso para SVG/scroll complexo, condicionado ao parecer jurídico.

### 4.2 Lottie (playback vetorial) vs animação programática

| | Lottie/dotLottie | Programática (Motion/Anime/GSAP) |
|---|---|---|
| Quem autora | Designer (AE/Bodymovin) | Engenheiro (código) |
| Determinismo | Alto (mesma animação sempre) | Alto, mas depende de código |
| Diff/review | Baixo (JSON binário-ish) | **Alto** (código em VCS) |
| Interação | Segmentos/markers limitados | Total |
| Conteúdo orgânico complexo | **Forte** (easings de designer) | Trabalhoso |
| Peso runtime | JSON/WASM leve | Lib JS |
| Uso Forge | Runtime de experiências geradas; previews | Cromo do editor; UI dinâmica |

**Combinação correta:** programática no editor; Lottie/dotLottie como **formato de entrega** de animações autoradas. Não usar Lottie como motor de lógica de jogo.

### 4.3 GSAP e a cláusula do Webflow — o que exatamente observar

**F (fetch_page gsap.com, 2026-11-14):** a Standard "No Charge" License define *Prohibited Uses* como "any implementation and/or use of GSAP Products in tools that allow users to build visual animations **without code** that encourages, induces, or materially assists in creating a solution that competes with Webflow's visual animation building capabilities" (*Competitive Products*). O FAQ esclarece que código **gerado por IA** não é uso proibido e que ferramentas visuais que não competem diretamente podem contatar a Webflow.

**I (inferência):** um módulo "Lia Animation" = construtor visual de timelines no-code, livremente disponível, com paleta de easings/drag-and-drop, seria exatamente o alvo da cláusula. O risco **não** é jurídico abstrato: é perder o direito de distribuir a Forge ou sofrer claim de IP.

**Postura recomendada:** (a) GSAP apenas para cromo interno enquanto não houver decisão humana; (b) qualquer editor visual de animação da Forge usa Motion/Anime/WAAPI próprias; (c) se GSAP for desejado no editor, obter consentimento escrito da Webflow; (d) registrar parecer jurídico antes de release.

### 4.4 Animação de personagem 2D (jogos gerados)

- **Spritesheets de quadros** (Blender/three.js → PNG seq → atlas): caminho nativo da Forge, determinístico, sem runtime especial — ver [`ASSET-PIPELINE-TOOLS-RESEARCH.md`](ASSET-PIPELINE-TOOLS-RESEARCH.md) §5 e [`BLENDER-MCP-RESEARCH.md`](BLENDER-MCP-RESEARCH.md) §5.
- **Esqueletal 2D**: Spine (padrão indústria; runtimes com licença proprietária + exigência de licença do usuário final → custo por título), DragonBones (MIT, estagnado), Inochi2D (LGPL; VTuber/live 2D niche).
- **Puppet vetorial interativo**: Rive (ver §3.5).
- **Decisão**: fora de escopo de adoção agora; documentar e deixar portão humano.

### 4.5 Física/easing/movimentos complexos

Springs (Motion/Anime) cobrem a maioria dos casos de UI; física de partícula/colisão real pertence a runtimes de jogo (three.js/babylon/phaser) ou ao Blender (baking) — **não** a libs de animação de UI. GSAP InertiaPlugin cobre inércia/limites de arraste se licença ok.

## 5. Combinações recomendadas (resumo)

| Combinação | Papel | Risco principal |
|---|---|---|
| Electron + React + **Motion** + dotLottie | Lia Forge (cromo + playback vetorial) | Baixo (MITs) |
| Electron + React + **Anime.js** + dotLottie | Variante framework-agnóstica/geração-agente | Baixo |
| Electron + **GSAP** (interno) | Demos/marketing/SVG avançado | Cláusula competitiva — parecer jurídico |
| **Rive** em experiências geradas | Personagem 2D interativo no produto final | Dependência de SaaS do editor |
| Blender → spritesheets + **PixiJS/three.js** | Animação de personagem em jogos gerados | Pipeline próprio = custo de engenharia |

## 6. Lacunas e bloqueios de pesquisa

1. **H** Tamanhos de bundle e nºs reais de performance (Motion vs Anime vs GSAP) **não medidos** nesta missão (nada instalado); exigem benchmark local autorizado.
2. Licença de uso dos **placeholders Motion+** não revisada por completo (núcleo é MIT; extras pagos à parte).
3. Preços Rive (planos) — site fora de alcance; **desconhecido**.
4. Correção de API v4 do anime.js confirmada só por fontes secundárias (animejs.com falhou HTTP 500); conferir documentação oficial na adoção.
5. Licença de saída de assets gerados em editores de terceiros (AE/Bodymovin, Rive) é do usuário desses editores — verificar ToS de cada conta antes de redistribuir no produto Forge.

## 7. Classificação consolidada

| Ferramenta | Classe | P |
|---|---|---|
| Motion (React/Vue/JS) | RECOMMENDED | P1 |
| Anime.js v4 | RECOMMENDED | P1 |
| Lottie / dotLottie | RECOMMENDED | P1 |
| GSAP (cromo interno) | EXPERIMENTAL | P2 |
| GSAP (editor visual no-code) | NOT-RECOMMENDED | — |
| Rive | EXPERIMENTAL | P2 |
| PixiJS (base 2D/atlases) | ALTERNATIVE | P2 |
| Phaser | RESEARCH-ONLY | P3 |
| Spine (distribuir) | NOT-RECOMMENDED sem compra | P3 |
| DragonBones / Inochi2D / Live2D | RESEARCH-ONLY | P3 |
| LibreSprite / Aseprite | ALTERNATIVE (P2) | P2 |

**Nada aqui autoriza adoção.** Toda adoção passa por: licença revisada → decisão humana → contrato/adapter próprio → teste. Ver [`LIA-FORGE-TOOLS-RECOMMENDATIONS.md`](LIA-FORGE-TOOLS-RECOMMENDATIONS.md).

## 8. Fontes

- GitHub API (2026-11-14): `juliangarnier/anime`, `motiondivision/motion`, `greensock/GSAP`, `airbnb/lottie-web`, `LottieFiles/dotlottie-web`, `rive-app/rive-runtime`, `pixijs/pixijs`, `phaserjs/phaser`, `DragonBones/DragonBonesJS`, `EsotericSoftware/spine-runtimes`, `LibreSprite/LibreSprite`, `aseprite/aseprite`.
- npm registry (2026-11-14): `animejs`, `motion`, `motion-v`, `gsap`, `lottie-web`, `@lottiefiles/dotlottie-web`, `@rive-app/canvas`, `@rive-app/react-canvas`, `pixi.js`, `phaser`.
- Licença GSAP primária: https://gsap.com/community/standard-license/ (fetch 2026-11-14).
- Avaliações secundárias anime.js v4: hysenlabs.com/projects/juliangarnier-anime; libhunt changelog. *(animejs.com inacessível — HTTP 500.)*
- Licensing GSAP/Webflow (secundário): noqode.fr; artofstyleframe.com; blog.openreplay.com.
