# BLENDER-MCP-RESEARCH — Automação, agentes e integração MCP com o Blender

**Data:** 2026-11-14 (UTC) · **Branch:** `arena/6113e868-lia-forge` · **Estado:** RESEARCH / planejamento — **não autoriza implementação, instalação, adoção de MCP, execução de scripts ou custo**.

**Escopo:** as duas integrações MCP apresentadas (Blender Lab oficial; `ahujasid/mcp-for-blender`) + alternativas relevantes; o que agentes conseguem executar com confiabilidade; segurança, permissões e isolamento; execução local vs. remota; múltiplos agentes; o que exige humano.

**Relacionados:** [`AGENT-SKILLS-MCP-IMPLEMENTATION-ASSESSMENT.md`](AGENT-SKILLS-MCP-IMPLEMENTATION-ASSESSMENT.md) (estado do código em `5b0ec51`), [`T14-AGENT-ECOSYSTEM-RESEARCH.md`](T14-AGENT-ECOSYSTEM-RESEARCH.md), [`T14-AGENT-SKILLS-MCP-MATRIX.md`](T14-AGENT-SKILLS-MCP-MATRIX.md), [`BLENDER-BRIDGE-SPECIFICATION.md`](BLENDER-BRIDGE-SPECIFICATION.md) (PROPOSED), [`auditoria-blender-local/`](auditoria-blender-local/README.md), [`ECOSYSTEM-RESEARCH-BLENDER-ADDONS.md`](ECOSYSTEM-RESEARCH-BLENDER-ADDONS.md).

**Convenções:** **F** fato verificado (GitHub API / fetch_page 2026-11-14) · **I** inferência · **H** hipótese.

---

## 1. Resumo executivo

- **F** Existem hoje **dois** caminhos MCP sérios para Blender — o oficial (Blender Lab) e o comunitário de maior adoção (`mcp-for-blender`) — e **ambos executam Python gerado por LLM dentro do Blender sem sandbox**. O oficial diz literalmente que não há guardas e recomenda VM. Isso não é um detalhe: é a propriedade definidora da categoria.
- **F** O oficial exige **Blender 5.1+** e foca em **análise/documentação/exploração de cenas**; o comunitário foca em **operar o Blender** (modelação, materiais, render, sprites) + integrações pagas (Poly Haven, Sketchfab, Meshy, Tripo, Rodin, Hunyuan3D, World Labs) — cada uma com custo/licença/exfiltração próprios.
- **F** Para a Forge, o caminho confiável e já alinhado à arquitetura é **scripts first-party headless** (`blender --background --python`, sem rede, sem LLM, auditáveis, com envelopes de proveniência). MCP externo é, no máximo, um **modo interativo opcional com guardas**, nunca um portão de qualidade.
- **Regra operacional:** nenhuma MCP de Blender entra em fluxo desatendido, em CI com segredos, ou com rede ligada. Qualquer saída de MCP passa pelo mesmo QA determinístico e pela mesma aprovação humana de qualquer asset.

## 2. As duas integrações oficiais/comunitárias em detalhe

### 2.1 Blender Lab MCP Server (oficial) — blender.org/lab/mcp-server

**F** (fetch_page da página oficial, 2026-11-14; fonte: https://www.blender.org/lab/mcp-server/ + https://projects.blender.org/lab/blender_mcp):

| Item | Detalhe declarado |
|---|---|
| Natureza | "A lightweight MCP server for Blender… natural language interface with Blender's Python API, improving access to documentation, and allowing users to explore and understand complex setups." |
| Requisitos | **Blender 5.1+**, Add-on **v1.0.3** (download direto `.zip`, ~`mcp-1.0.3.zip`), um **LLM Client** (a página referencia a wiki de llama.cpp e "qualquer cliente MCP compatível"), o **MCP Server** (bundle `.mcpb` para clientes novos, ou instalação do fonte) |
| Instalação | Manual: add-on (drag-and-drop/Install from Disk) + MCP server; nada é embutido no Blender — "**Blender does not have any built-in functionality for connecting to LLMs**" |
| **Aviso de segurança textual** | "The MCP server will execute LLM generated code in Blender **without any guards in place to protect your data from removal or being sent to a remote location**. To keep your data safe it is recommended to use a **virtual machine**, or a system without access to sensitive information." |
| Casos de uso demonstrados | Análise de cena (outliers de polycount vs tela), renomeação de data-blocks, explicação de Geometry Nodes + frames/Text datablock, checklist de boas práticas ("meshes must be manifold… naming… no absolute paths"), debug de cena |
| Reliability | A própria página admite que a "confiabilidade dos resultados" depende do modelo e mostra análise parcialmente errada (Solidify ignorado) |
| Licença/estado | Add-on via Blender Lab (projects.blender.org — instância GitLab da Blender Foundation); **licença não declarada na página** (Blender é GPL-3.0-or-later; o MCP server provavelmente segue — **verificar antes de redistribuir/embutir**); versão add-on 1.0.3 ⇒ projeto novo |
| Release cycle | Repositório `projects.blender.org/lab/blender_mcp`; wiki com guias llama.cpp/Setup |

**Leitura (I):** é uma ferramenta de **compreensão** ("o que este .blend faz?"), não de **produção garantida**. Excelente para auditoria assistida de arquivos existentes (exatamente o caso da `auditoria-blender-local/`), sempre em VM e com revisão humana das conclusões. **Não** é executor de pipelines; **não** tem contrato de saída; **não** tem noção de proveniência.

### 2.2 `ahujasid/mcp-for-blender` (comunitário)

**F** (GitHub API + README, 2026-11-14/15; repo pushed 2026-11-15):

| Item | Detalhe |
|---|---|
| Licença | **MIT** |
| Stars / issues | 34.5 mil · issues abertas altas (não contadas nesta verificação) |
| Releases | **Nenhuma** (instalação via `uvx mcp-for-blender` / pip; sem tags GitHub) |
| Arquitetura | Add-on Blender (`addon.py`) → socket TCP `localhost:9876`; servidor MCP (Python, FastMCP-style) ↔ LLM client |
| Execução | **`execute_blender_code`: Python arbitrário por padrão.** Guarda opcional: `BLENDER_MCP_SAFE_MODE=1` valida o script e bloqueia escrita/leitura direta de arquivos, subprocessos, rede e persistência pós-script; scripts bloqueados retornam motivo ao agente |
| Socket | **Sem autenticação nem criptografia** (texto oficial: "anyone who can reach that port can run Python inside Blender"); recomenda localhost/SSH tunnel |
| Ferramentas (amostra) | `get_scene_info`, `get_screenshot` (viewport inline), `get_object_info`, `execute_blender_code`, `set_texture`, Poly Haven (search/download ~2.400 HDRI/tex/modelos), Sketchfab, Poly Pizza, geração 3D por IA (Meshy, Tripo, Hyper3D Rodin, Hunyuan3D — via API key própria ou "Premium" pago embutido), World Labs (Gaussian splats), `generate_3d`, `disable_telemetry`, `record_trajectory_feedback` |
| Telemetria | **Opt-in para conteúdo; mas registro anônimo mínimo (install ID, tool, duração, versões, OS) é coletado por padrão** — desligar com `DISABLE_TELEMETRY=true` ou checkbox no add-on |
| Risco de exfiltração | Integrações premium enviam **prompts/imagens de referência para serviços externos** (Tencent Cloud Hunyuan, Meshy, Tripo…) — **proibido sem autorização explícita e sem revisão de licença dos assets resultantes** |
| Salvaguarda do próprio autor | "**ALWAYS save your work before using it**"; operações complexas exigem decomposição |
| Multi-instância | Múltiplos clientes/portas suportados (`--port 9877` + porta correspondente no painel) — mas cada Blender continua um singleton com estado compartilhado |

**Leitura (I):** o toolset é vasto e funciona para **exploração interativa acelerada** (o que a maioria dos demos mostra). Para a Forge, tudo que ele faz de valioso **já existe deterministicamente** via bpy headless — e tudo que ele faz além disso (IA 3D, assets remotos) é exatamente o que a Forge **não pode** acionar sem decisão humana, custo e licença. `SAFE_MODE=1` reduz risco destrutivo, mas **não** audita qualidade, **não** garante correção semântica e **não** cria proveniência.

### 2.3 Alternativas e ruído de mercado (GitHub search, 2026-11-14)

| Projeto | Licença · stars · push | Observação |
|---|---|---|
| `hitkeeen/blender-ai-mcp-addon` | MIT · 1,9 mil · 2026-11-12 | Comunitário menor; sem auditoria |
| `scenario-labs/blender-plugin` | **GPL-3.0** · 1,0 mil · 2026-11-13 | Plugin do serviço Scenario (IA p/ game assets); acoplado a conta paga; GPL no plugin |
| `scenario-labs/skills`, `arjun988/blender-skills` | MIT · 3,8 mil · 2026-11 | Packs de "skills" para agentes; pesquisa, não adoção |
| Cluster `blender-ai-copilot-*` (`credoksopho1984`, `racdeu…`, `tiobe…`, `zovul…`, `Doug-218`, `precyg…`) | MIT · ~0,5 mil cada · 2026-11 | Padrão de repos SEO/mirror; **não confiar por ranking de busca** — verificar autoria, idade, conteúdo antes de qualquer consideração |
| `bpy` no PyPI (roda Blender como módulo Python) | **GPL-3.0** · v5.3.0 | Útil em CI; obrigações GPL; wheels pesadas; **verificar plataforma** (Win/Linux) antes de cogitar |

Nenhum desses substitui o caminho first-party. Pesquisa não executada: nenhum foi clonado/instalado.

## 3. O que agentes conseguem fazer com confiabilidade no Blender

Classificação por natureza da tarefa (não por ferramenta):

| Classe | Exemplos | Confiabilidade | Onde roda |
|---|---|---|---|
| **Determinístico automatizável** | importar/converter (glTF/FBX/OBJ), aplicar transforms, recalcular normais, validar manifold/UVs, renomear por convenção, decimar, bake de texturas, render turntable/spritesheet (câmera+action fixos), screenshots, relatórios | Alta (repetível; testável; gates possíveis) | **Script first-party headless** — nunca via LLM |
| **LLM-assistido com revisão** | propor renomeações, documentar Geometry Nodes, diagnosticar "por que o rig não deforma", montar checklist de auditoria de arquivo | Média (erros sutis; sempre humano no laço) | MCP interativo (VM) ou copiloto do artista |
| **LLM gen-art desatendido** | modelar personagem do zero, retopology criativa, rigg com ik/fk completo, animar walk cycle, materiais "de estilo" | **Baixa–média; exige humano** | Nunca desatendido; nem com SAFE_MODE |
| **Fora de escopo de agente** | julgamento de qualidade/marca, aprovação final, licenciamento de asset, decisões de custo | N/A | Humano |

**O que "SAFE_MODE" não salva:** asset feio/errado com código rodando limpo; vazamento via clipboard/viewport em máquina compartilhada; estado residual entre execuções no mesmo Blender; prompt injection embutida em assets/cenas (ex.: nome de objeto malicioso instruindo o agente — tratar **conteúdo de arquivo como dado não-confiável**).

## 4. Segurança, permissões e isolamento — padrão mínimo para qualquer uso

1. **Ambiente:** VM ou máquina sem dados sensíveis (exigência textual dos dois projetos); idealmente container descartável sem rede (`--network=none`), com o `.blend` de entrada montado read-only e pasta de saída única.
2. **Rede:** MCP blender → **localhost apenas**; nunca expor 9876; sem port-forward; sem VPN compartilhada. Bloqueio de egress no host.
3. **Credenciais:** nenhuma API key (Meshy/Telemetria/HF) em variáveis de ambiente de runs automatizados; `DISABLE_TELEMETRY=true` como padrão do ambiente da Forge; checar checkbox de telemetria no add-on (default do projeto coleta registro mínimo anônimo).
4. **Permissão:** execução de MCP/bpy **fora** da árvore de aprovação da Forge exige portão humano (mesma classe das `PROTECTED_ACTIONS` já existentes em `5b0ec51`); saída = staging + QA + envelope de proveniência — nunca direto no projeto.
5. **Rollback:** snapshot/commit do projeto **antes** de qualquer agente tocar em arquivos-fonte; Blender via MCP **sempre** abre cópia (never in-place edit de masters).
6. **Auditoria:** log de cada tool call + prompt + artefato; retenção local; comparação hash pré/pós.
7. **Múltiplos agentes:** 1 Blender = 1 processo = 1 tarefa por vez; paralelizar por **processos** (portas/instâncias separadas, como o README documenta `--port`), nunca por threads no mesmo arquivo; preferir sempre processos frescos.
8. **Conteúdo não-confiável:** cenas/assets de terceiros são entrada hostil — o agente não deve ler instruções de dentro de dados (prompt injection).

## 5. Combinações que fazem sentido

| Combinação | Uso | Veredito |
|---|---|---|
| bpy first-party headless + envelopes Forge | **Toda produção repetível** | **RECOMMENDED (P0)** — é o que já existe em `5b0ec51` |
| Blender Lab MCP em VM, humano no laço | Auditoria assistida de `.blend` legados (ex.: renomear 40k datablocks) | EXPERIMENTAL (P3) |
| mcp-for-blender + SAFE_MODE + localhost + telemetry off, interativo | Prototipagem com artista pilotando | EXPERIMENTAL (P3) — nunca no pipeline |
| mcp-for-blender "Premium"/Hunyuan/Meshy/Tripo | Geração AI de modelos | NOT-RECOMMENDED sem autorização de custo + revisão de licença + política de dados |
| bpy via PyPI em CI | Jobs sem Blender instalado | ALTERNATIVE (P2) — GPL-3.0 + tamanho |
| Blender render → three.js inspect → QA gates → pacote | Pipeline Lia3DSprite | **RECOMMENDED** (arquitetura já proposta; ver [`threejs-3d-environment/`](threejs-3d-environment/README.md)) |

## 6. Matriz de decisão rápida

| Critério | Blender Lab MCP (oficial) | mcp-for-blender (comunitário) | bpy first-party |
|---|---|---|---|
| Propósito primário | Entender/analisar cena | Operar Blender via agente | Produção determinística |
| Requer Blender ≥ 5.1 | Sim | Não (3.x+; testar 4.5/5.x) | Qualquer (4.5 LTS+/5.x) |
| Guardas nativos | Nenhum (VM recomendada) | `SAFE_MODE=1` (opcional) | **Sem LLM — sem problema por construção** |
| Rede | LLM local ou externo (você escolhe) | Integrações externas embutidas | Nenhuma necessária |
| Contrato de saída | Nenhum | Nenhum | Envelope próprio (hash/metadados) |
| Automação não-assistida | Não | **Não** | Sim |
| Risco de custo | Baixo (só LLM) | **Alto** (Premium/API keys) | Nulo |
| Licença | Verificar (Blender Lab; provável GPL) | MIT | GPL (interage com Blender) — uso interno ok; redistribuição exige cuidado |
| Veredito Forge | Ferramenta de auditoria, P3 | Nunca no pipeline | **Rota principal** |

## 7. Lacunas e bloqueios de pesquisa

1. Licença exata do Blender Lab MCP server + add-on **não visível na página** — obter antes de qualquer embutimento (provável GPL-3.0; não redistribuir sem confirmar).
2. **H** `bpy` PyPI (5.3.0) em Windows: plataforma/tamanho/deps não verificados (só PyPI JSON); Linux confirmado genericamente.
3. Comportamento de `SAFE_MODE` não testado (nada instalado); assumir heurística falível.
4. Telemetria default-on do mcp-for-blender: **verificada por README**, mas comportamento de rede não inspecionado em tráfego real.
5. Blender 5.1/5.3 existência recente (5.1 lançado 2026-03-17; PyPI bpy 5.3.0) — verificar versões LTS vigentes na adoção.
6. Nada aqui foi executado: nenhuma cena, nenhum agente, nenhum render.

## 8. Classificação consolidada

| Opção | Classe | P |
|---|---|---|
| bpy headless first-party (processo próprio, sem rede/LLM) | RECOMMENDED | P0 |
| Blender Lab MCP (VM, humano no laço, análise/docs) | EXPERIMENTAL | P3 |
| `mcp-for-blender` interativo (SAFE_MODE+localhost+telemetry off) | EXPERIMENTAL | P3 |
| `mcp-for-blender` desatendido / em pipeline / CI | NOT-RECOMMENDED | — |
| Integrações pagas (Meshy/Tripo/Rodin/Hunyuan/WorldLabs) | NOT-RECOMMENDED sem autorização | — |
| `bpy` PyPI em CI | ALTERNATIVE | P2 |
| Skills packs (`blender-skills`, `scenario-labs/skills`) | RESEARCH-ONLY | P3 |
| Repos `blender-ai-copilot-*` | NOT-RECOMMENDED (proveniência) | — |

## 9. Fontes

- Página oficial Blender Lab MCP Server: https://www.blender.org/lab/mcp-server/ (fetch_page 2026-11-14; aviso de segurança e requisitos transcritos literalmente).
- Código-fonte anunciado: https://projects.blender.org/lab/blender_mcp (não inspecionado — fora do GitHub/npm/PyPI).
- `ahujasid/mcp-for-blender`: GitHub API + README completo (2026-11-15; `SAFE_MODE`, socket, telemetria, integrações, aviso "save your work").
- GitHub search (2026-11-14): `blender mcp` ordenado por stars; cluster `blender-ai-copilot-*`.
- PyPI: `bpy 5.3.0` (GPL-3.0).
- Repositório: `docs/AGENT-SKILLS-MCP-IMPLEMENTATION-ASSESSMENT.md`, `docs/BLENDER-BRIDGE-SPECIFICATION.md`, `docs/auditoria-blender-local/`.
- Blender 5.1 (2026-03-17): Phoronix; HIP-RT AMD: Phoronix. Vulkan experimental: PR #113057 (Blender Projects).
