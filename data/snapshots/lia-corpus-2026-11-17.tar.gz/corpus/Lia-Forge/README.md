# Lia Forge — Game Asset Studio

Lia Forge é a ferramenta do ecossistema Lia voltada à organização e produção de assets para jogos.

Este arquivo descreve a identidade do produto; consulte o conteúdo efetivamente presente neste branch para confirmar o estado de implementação. Não presuma que funcionalidades de branches de trabalho já foram integradas.

## Padrões e documentação

- [`docs/BRAND-STANDARDS.md`](docs/BRAND-STANDARDS.md) — princípios comuns da marca Lia.
- `AGENTS.md` — regras de trabalho para agentes.
- `docs/` — documentação técnica e de produto presente neste branch.

### Índice de documentação técnica (pesquisa e planejamento)

- [`docs/RESEARCH-CONSOLIDATION-2026-11-13.md`](docs/RESEARCH-CONSOLIDATION-2026-11-13.md) — consolidação dos pacotes de pesquisa Blender/Three.js/T14 (nada aqui implica implementação).
- [`docs/threejs-3d-environment/`](docs/threejs-3d-environment/README.md) — pacote completo de pesquisa Three.js para o viewport da Forge (r187, WebGL2).
- [`docs/T14-AGENT-ECOSYSTEM-RESEARCH.md`](docs/T14-AGENT-ECOSYSTEM-RESEARCH.md), [`docs/T14-AGENT-ORCHESTRATION-ARCHITECTURE.md`](docs/T14-AGENT-ORCHESTRATION-ARCHITECTURE.md), [`docs/T14-AGENT-SKILLS-MCP-MATRIX.md`](docs/T14-AGENT-SKILLS-MCP-MATRIX.md), [`docs/T14-AGENT-SOLUTIONS-CATALOG.md`](docs/T14-AGENT-SOLUTIONS-CATALOG.md) — ecossistema de agentes e automação (T14).
- [`docs/AGENT-SKILLS-MCP-IMPLEMENTATION-ASSESSMENT.md`](docs/AGENT-SKILLS-MCP-IMPLEMENTATION-ASSESSMENT.md) — auditoria do que existe de verdade (agentes, Skills, MCP) no branch T13 não integrado; lacunas e próxima fatia.
- [`docs/ANIMATION-TOOLS-RESEARCH.md`](docs/ANIMATION-TOOLS-RESEARCH.md) — anime.js, Motion, GSAP, Lottie/dotLottie, Rive e animação 2D.
- [`docs/3D-RENDERING-TOOLS-RESEARCH.md`](docs/3D-RENDERING-TOOLS-RESEARCH.md) — Three.js vs react-three-fiber vs Babylon/PlayCanvas; spritesheets a partir de 3D; hardware RX 580.
- [`docs/BLENDER-MCP-RESEARCH.md`](docs/BLENDER-MCP-RESEARCH.md) — MCP oficial (Blender Lab) vs `mcp-for-blender` vs bpy headless; segurança e automação.
- [`docs/ASSET-PIPELINE-TOOLS-RESEARCH.md`](docs/ASSET-PIPELINE-TOOLS-RESEARCH.md) — conversão/otimização/validação glTF, texturas, spritesheets, Remotion.
- [`docs/COLIBRI-TECHNICAL-RESEARCH.md`](docs/COLIBRI-TECHNICAL-RESEARCH.md) — avaliação técnica do CoLibrì (inferência local de MoE); por que não é ferramenta de assets.
- [`docs/TOOLS-COMPARISON-MATRIX.md`](docs/TOOLS-COMPARISON-MATRIX.md) — matriz comparativa consolidada de todas as ferramentas.
- [`docs/LIA-FORGE-TOOLS-RECOMMENDATIONS.md`](docs/LIA-FORGE-TOOLS-RECOMMENDATIONS.md) — recomendações, combinações, prioridades, riscos e decisões humanas pendentes.
- [`docs/BLENDER-BRIDGE-SPECIFICATION.md`](docs/BLENDER-BRIDGE-SPECIFICATION.md) — especificação PROPOSED da ponte Blender↔Forge.
- [`docs/ECOSYSTEM-RESEARCH-BLENDER-ADDONS.md`](docs/ECOSYSTEM-RESEARCH-BLENDER-ADDONS.md), [`docs/BLENDER-ADDONS-MATRICES.md`](docs/BLENDER-ADDONS-MATRICES.md) — auditoria de add-ons Blender.
- [`docs/auditoria-blender-local/`](docs/auditoria-blender-local/README.md) — auditoria dos arquivos locais do usuário.

A licença do código não concede automaticamente direitos sobre a marca, personagem, logotipos ou assets proprietários.
