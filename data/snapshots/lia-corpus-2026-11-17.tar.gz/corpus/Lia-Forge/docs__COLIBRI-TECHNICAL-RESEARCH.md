# COLIBRI-TECHNICAL-RESEARCH — Avaliação técnica do projeto CoLibrì (`JustVugg/colibri`)

**Data:** 2026-11-14 (UTC) · **Branch:** `arena/6113e868-lia-forge` · **Estado:** RESEARCH — **não autoriza instalação, execução, download de modelos, custo ou adoção**.

**Pergunta central:** o que é o CoLibrì, para que serve, como funciona, e onde (se em algum lugar) ele agrega valor ao Lia Forge?

**Fontes primárias usadas:** README.pt-BR.md do repositório (clonado raso, somente leitura), `LICENSE`/`NOTICE`, `docs/MCP_SERVER.md`, `docs/…` (lista), e GitHub API (metadados, releases). Nenhuma linha de código foi executada; nenhum modelo foi baixado; o site `justvugg.github.io/colibri` **não** foi verificado (fora do alcance).

**Convenções:** **F** fato verificado · **I** inferência · **H** hipótese. Medições de desempenho citadas são **do autor do projeto**, não reproduzidas.

---

## 1. Resumo executivo

- **F** CoLibrì ("colibrì: motor minúsculo, modelo imenso") é um **motor de inferência local, em C puro, para LLMs abertos de mistura de especialistas (MoE) de centenas de bilhões de parâmetros**. A parte densa do modelo fica na RAM; os especialistas roteados ficam no disco (NVMe) e são lidos sob demanda conforme o roteador os pede. Não exige GPU.
- **F** Ele **não é** uma ferramenta de assets, animação, 3D ou um framework de agentes. É um **provider de inferência** (endpoints HTTP OpenAI/Anthropic-compatible) + um **modo de decisão tipada** ("System One") + um **servidor MCP de gerenciamento** (detectar hardware, recomendar/instalar/iniciar/parar/verificar o motor).
- **F** Para o hardware de referência da Forge (RX 580 8 GB · Ryzen 5 5500 · 16 GB · Windows), apenas os modelos **pequenos** são executáveis com folga razoável (ex.: OLMoE 7B, Flint 40B UD-IQ1_M, Qwen3-Coder-30B-A3B) — e a **velocidade é de segundos por token nos maiores**. O caso de uso realista é agente de texto/tool-calling em lote, não interação de artista, e jamais geração de imagem para produto (ver §7, "Qwen-Image-2.1": **licença não comercial**).
- **I** Relação com a Forge: **provider opcional de LLM local** para os workflows de agente (já previstos na T14 como "LLM local"), atrás dos mesmos adapters/contratos de qualquer provider. Alternativas mais simples e maduras para o porte (llama.cpp, Ollama) cobrem o caso de modelos ≤30B com muito menos fricção.
- **Veredito:** **RESEARCH-ONLY / EXPERIMENTAL (P3)**. Não instalar, não baixar modelos, não usar em pipeline. Reavaliar apenas se (a) um agente local for autorizado **e** (b) um modelo ≤30B for escolhido **e** (c) benchmark on-target aprovar.

## 2. O que é — definição precisa (F)

| Item | Detalhe |
|---|---|
| Repositório | `github.com/JustVugg/colibri` · default branch `main` |
| Criação / último push | 2026-07-01 / 2026-11-16 |
| Licença (código) | **Apache-2.0** (`LICENSE`/`NOTICE` © 2026 Vincenzo Fornaro) + `THIRD_PARTY_NOTICES.md` |
| Stars / forks / issues | 51.446 / 6.219 / 172 (2026-11-14) — altíssimo interesse; projeto de ~4 meses; **maturidade experimental de longo prazo** (não é software de década) |
| Versão / release | `v2.1.0` (2026-10-31) |
| Linguagem | **C puro**; um arquivo por família de modelo; build via `Makefile`; sem Python no runtime (Python 3.10+ só no setup/MCP) |
| Plataformas/backends | CPU (sempre) · **Vulkan 1.2** qualquer GPU (AMD/Intel/NVIDIA — integrada aceita em 3 motores medidos) · **CUDA** (NVIDIA, Linux/Windows; Windows via `coli_cuda.dll` separada, compute capability ≥ 8.0 ⇒ **RTX 3000+**) · **Metal** (Apple Silicon) · "Sem Resizable BAR" tratado por buffer intermediário |
| Instalação declarada | `START-HERE.bat` (Windows) / `./start-here.sh` (Linux) — **baixa modelos de dezenas–centenas de GB do Hugging Face e compila/baixa o motor**; **proibido executar nesta missão** |
| Endpoints | `http://127.0.0.1:8000/v1` (OpenAI) · `http://127.0.0.1:8000/` (Anthropic) · `/v1/systemone` (decisões tipadas) · painel web embutido |
| MCP | `coli mcp` (stdio, JSON-RPC, stdlib-only): tools de **detecção de hardware, recomendação, instalação, start/stop/status** — gestão do próprio motor, **não** tools de criação de conteúdo |
| Tamanho mínimo p/ rodar | ≥ 8 GB RAM (16+ recomendado) · ≥ 22 GB disco p/ o menor modelo |

### 2.1 Motores de modelo embutidos (F, do README)

13 motores: 10 LLMs (**GLM-5.2/5.3** e Mistral-Large-4 no motor GLM; GLM-5.3-Flash; Inkling; **Kimi K3**; **DeepSeek V4 Flash / V4.1 Flash**; **MiMo-V2.6 Flash/Pro**; **Qwen3.8-Flash-Next** / Qwen3.6 (roda também Qwen3-Coder, Qwen3.8-27B denso, Flint, Muse Spark Open, LFM3-VL); **OLMoE**) · 1 desenho de figura (**Qwen-Image-2.1**, 33 GB, Vulkan, **licença não comercial**) · 2 decisão (**Laya**, **GLiNER2.5-Decide**, + Clef no motor Qwen3.6).

Faixa de tamanhos (F, tabela do README): de **14 GB→7 GB** (OLMoE int8) e **11,4 GB** (Flint UD-IQ1_M) até **1,56 TB** (Kimi K3). GLM-5.2 (744B): 429 GB, ~0,9–2 tok/s em desktops de 32 GB, 9 tok/s em 6× RTX 5090.

### 2.2 Como funciona (F/I)

1. **Particionamento denso/esparso.** Num MoE, cada token ativa só uma fração ("5,4%" no exemplo GLM-5.2). CoLibrì mantém atenção/embeddings/experts compartilhados na RAM; especialistas roteados ficam em disco e são paginados por um **cache adaptativo** ("hot experts") — com medições de acerto por máquina.
2. **Aprendizado de cache por uso.** A configuração registra quais especialistas suas conversas usam e pré-carrega na GPU (quando há).
3. **Backends.** CPU puro (baseline); Vulkan (cache de especialistas + "cadeia densa" como uma submissão única); CUDA (camadas/tensor-cores, inclusive blocos GGUF direto em placa); Metal.
4. **GGUF nativo.** Lê GGUF publicados "como são" (IQ1_S→Q8_0/F16/MXFP4…) sem requantização; `./coli import` propaga para um dir de modelo.
5. **System One.** `POST /v1/systemone` recebe estado + perguntas tipadas (`choice`, `noul`, `score`) e devolve **probabilidades por opção + confidence**, sem gerar texto — "o modelo não tem certeza" vira número com limiar. Calibrado por autores via modelos dedicados (Laya, GLiNER2.5-Decide) ou por pontuação com qualquer chat model.
6. **Painel + API + MCP.** UI local mostra especialistas ativos por token; endpoints compatíveis permitem reusar clientes OpenAI/Anthropic/Jev sem mudança (só `TYPESAFE_BASE_URL`).

## 3. Requisitos e encaixe no hardware de referência (RX 580 8 GB · 5500 · 16 GB · Windows)

| Quesito | Encaixe |
|---|---|
| GPU | RX 580 **não tem CUDA** (e o build CUDA do projeto exige cc ≥ 8.0); caminho = **Vulkan 1.2** (o projeto exige só Vulkan 1.2; driver oficial AMD Windows lista RX 400–600 como suportados para Vulkan — **I**: precisa validar no alvo; POL/GCN4 não tem ray accelerators, irrelevante p/ LLM) ou **CPU** |
| RAM 16 GB | Suficiente para os pequenos: OLMoE (8 GB), Flint UD-IQ1_M (11,4 GB download; ~11–12 GB RAM int4-ish), Qwen3-Coder-30B-A3B (**8 GB mín / 18 GB p/ velocidade cheia** — no alvo, rodará com redução de especialistas/camadas, ~5 tok/s CPU medido pelo autor em máquina similar); Qwen3.6-35B **não recomendado** (10 min/20 GB recomendados) |
| Disco | **NVMe obrigatório** p/ modelos que streamam (os 14–30B pequenos cabem em RAM, disco não é crítico). 22 GB livres mínimo declarado; na prática, 30–60 GB |
| Windows | Suportado (`.bat`, DLLs CUDA pré-compiladas em releases, Vulkan); o CUDA do Windows vem em DLL separada |
| Latência percebida | Chat interativo: **não** (5–30 tok/s em 7–35B é utilizável; raciocínio longo de agente = minutos); lote/overnight: sim |
| Custos | Zero de licença do motor; **custos de disco/banda** (downloads de 11–429 GB) e de eletricidade/tempo; nenhum serviço pago necessário; HF pode exigir token p/ repos gated |

**Conclusão de hardware (I):** executável apenas na faixa "pequeno"; medir no alvo antes de qualquer decisão (nenhum benchmark foi executado nesta pesquisa — não autorizado).

## 4. Licenças — separação obrigatória (F)

| Camada | Licença | Implicação |
|---|---|---|
| Código CoLibrì | **Apache-2.0** | Uso/modificação/redistribuição livres; NOTICE obrigatório; sem copyleft |
| Modelos | **Cada um com a sua** | Qwen (Apache-2.0 em vários, mas **não todos**), DeepSeek (MIT em vários), GLM (licença própria Zhipu), Kimi (própria), Meta Muse Spark (acordo Meta), LFM3-VL (LFM Open License), Laya/GLiNER (propriedades de terceiros), **Qwen-Image-2.1 — NÃO COMERCIAL (declarado)** |
| Pesos GGUF (unsloth etc.) | Herdam a licença do modelo base | Verificar card do repo HF de cada quantização (I) |
| Assets gerados por Qwen-Image-2.1 | **Proibido uso comercial** | Nunca para assets do produto |
| Dados de treino/Consent | Desconhecido/heterogêneo | Não confiar para conteúdo sensível |

**Regra Forge:** nenhuma adoção de modelo sem verificação do card de licença específico da quantização escolhida + registro no envelope de proveniência. Apache-2.0 do motor **não** cobre pesos nem saídas.

## 5. Comparação com alternativas (caso de uso: LLM local para agentes da Forge)

| | **CoLibrì** | **llama.cpp** | **Ollama** | **LM Studio** |
|---|---|---|---|---|
| Foco | MoE **gigantes** em RAM modesta (streaming de especialistas) | Inference universal (densos/MoE ≤ tamanho da RAM) | Wrapper de usabilidade sobre llama.cpp-like + registry | GUI + servidor OpenAI-compatible |
| Licença | Apache-2.0 | MIT | MIT | Proprietário (grátis) |
| Stars · push | 51,4 mil · 2026-11-16 | 135 mil · 2026-11-16 | 187 mil · 2026-11-15 | n/a (closed) |
| Instalação | Script + download de dezenas–centenas GB | build/releases; `llama-cli`/`llama-server` | Instalador único | Instalador |
| Hardware-alvo | CPU/Vulkan/CUDA; NVMe rápido | CPU/CUDA/Metal/Vulkan(SYCL pull) | idem llama.cpp | idem |
| Modelos Forge-relevantes | Qwen3-Coder-30B, Flint, OLMoE | Qualquer GGUF ≤ RAM | Qualquer GGUF ≤ RAM | qualquer |
| Manutenção | 1 autor (suporte comunitário; 172 issues) | Grande comunidade | Grande empresa + OSS | Empresa |
| Painel/MCP | Embutido (`coli mcp` p/ setup) | `llama-server` + endpoints | API + CLI + biblioteca | GUI + API |
| Ajuste fino p/ agente (tools) | Depende do modelo (Qwen3-Coder forte) | idem | idem | idem |

**Leitura:** para **agentes de texto/QA** (caso Forge), llama.cpp/Ollama entregam o mesmo com fração da complexidade e da banda. CoLibrì só é racional se a exigência for **"100B+ offline"** — inexistente hoje nos workflows da Forge (ver T14: modelos 7–30B locais já são "plausível só para assistência").

## 6. Aplicações possíveis na Lia Forge (I, pós-autorização)

| Capacidade Forge | Aplicação | Veredito |
|---|---|---|
| **Lia Agent Workflows** (provider local de LLM) | Endpoint OpenAI-compatible; adapter `provider:openai-compatible` já previsível na arquitetura; zero mudança de contrato | **Única aplicação legítima** — e mesmo assim, preferir Ollama/llama.cpp; CoLibrì = EXPERIMENTAL |
| **QA/triagem com System One** (ex.: "esta cena tem problema óbvio? sim/não + confidence") | Threshold de confiança p/ pré-classificar findings; humano confirma | EXPERIMENTAL — sem calibração própria, não vira portão |
| Lia2DCreate / Lia3DSprite | **Nenhuma** (sem tools de imagem/sprite; Qwen-Image é não-comercial) | N/A |
| Lia Scene / Lia Render | Nenhuma | N/A |
| **Assets** (qualquer) | **Nenhuma via CoLibrì** | NOT-RECOMMENDED |
| Governança/custos | Demonstra como manter LLM **100% local, zero egress** — princípio alinhado à Forge | Referência arquitetural (RESEARCH) |

## 7. Riscos e bloqueios

1. **Projeto jovem** (~4 meses): breaking changes frequentes (v2.1.0), um único mantenedor, nenhum SLA; issues altas; sem auditoria independente; README com claims de benchmark **não reproduzidos** nesta pesquisa.
2. **Downloads massivos** (7–429 GB; 1,5 TB no limite) — custo de banda/disco e tempo; risco de interrupção no meio (retomável, declarado).
3. **Licenças de modelos** heterogêneas; **Qwen-Image-2.1 explicitamente não comercial** — qualquer uso em assets do produto é violação.
4. **Instalador auto-executável** (`START-HERE.bat` baixa pacotes e compila): contraria "não executar scripts desconhecidos" — **não rodar** sem autorização expressa e leitura prévia do script.
5. **Dados**: logs/painéis ficam locais (bom), mas `nanochat`-style telemetry? Não declarada — assumir ausência não verificada; tratar prompts de brief como sensíveis igualmente.
6. **Precisão/alucinação** de LLM local fraco (30B) em tarefas de QA estrutural com saída JSON: taxa de erro real desconhecida; **nunca** como único portão (humano sempre).
7. **Windows CUDA** = cc ≥ 8.0 (RTX 30xx+); RX 580 está fora — caminho é Vulkan/CPU (lento).
8. **Conteúdo do repositório** (`flake.nix`, `docker/`, `web/`) não auditado; `THIRD_PARTY_NOTICES` não lido por completo.
9. Modelos mencionados (GLM-5.2/5.3, Kimi K3, DeepSeek V4…) são de 2026 e **não** foram verificados contra Hugging Face nesta pesquisa (escopo); tratar como declarados pelo autor.

## 8. Comparação direta pedida: "Colibri vs outras soluções que atendam à mesma finalidade"

**Mesma finalidade = inferência local de LLM open-weight.** Ranking para o perfil Forge (RX 580 · 16 GB · agente interativo/lote leve):

1. **Ollama** — menor atrito, maior comunidade, MIT → **default se/quando um provider local for autorizado**.
2. **llama.cpp** — controle fino, MIT, ótimo p/ embutir via sidecar.
3. **CoLibrì** — só se a política exigir >100B local (não é o caso) → RESEARCH-ONLY.
4. **vLLM/SGLang/TensorRT-LLM** — servidor multi-GPU Linux; fora do alvo Windows/RX 580.
5. **APIs comerciais (OpenAI/Anthropic/Google)** — já avaliadas na T14; exigem chave/custo/autorização de dados; não são "locais".

## 9. Classificação

| Uso pretendido | Classe | P |
|---|---|---|
| Provider local de LLM p/ workflows (genérico) | ALTERNATIVE (atrás de Ollama/llama.cpp) | P3 |
| System One como pré-triagem QA (pós-benchmark e calibração) | EXPERIMENTAL | P3 |
| Referência de arquitetura "local-first/zero-egress" | RESEARCH-ONLY | P3 |
| Geração de imagem/asset para o produto | NOT-RECOMMENDED | — |
| Instalação/uso imediato no pipeline | NOT-RECOMMENDED (sem autorização; demais riscos) | — |

## 10. O que seria necessário antes de qualquer avanço (portões)

1. Decisão humana: "provider local de LLM é desejável?" (T13/T14 já tratam; nada implementado).
2. Se sim: comparar Ollama vs llama.cpp vs CoLibrì **em benchmark no alvo** (autorização para instalar; medir tokens/s, RAM, estabilidade em tool-calling JSON).
3. Escolha de modelo ≤ 30B com licença permissiva verificada (ex.: Qwen3-Coder-class, Apache/MIT) — nunca Qwen-Image p/ assets.
4. Integração **via adapter** (`provider:openai-compatible`), atrás de feature flag, com timeout/retries/custo declarado e logs sem dados sensíveis.
5. QA independente + aprovação humana; nenhuma decisão de portão delegada ao modelo.
6. Registro no envelope de proveniência (qual modelo, qual quantização, qual licença, qual hash).

## 11. Fontes

- `JustVugg/colibri` — README.pt-BR.md (lido integralmente, 2026-11-14), `LICENSE`, `NOTICE`, `docs/MCP_SERVER.md`, listagem `docs/`; GitHub API: v2.1.0 (2026-10-31), created 2026-07-01, pushed 2026-11-16, 51.446 stars, 6.219 forks, 172 issues, Apache-2.0.
- GitHub API (2026-11-14): `ollama/ollama` (MIT, 187 mil), `ggml-org/llama.cpp` (MIT, 135 mil).
- Remotion/other fontes: ver docs irmãos desta série.
- Hardware target: auditorias anteriores do repositório (`T14-AGENT-ECOSYSTEM-RESEARCH.md` — "RX 580, gfx803, sem ROCm"; `ECOSYSTEM-RESEARCH-BLENDER-ADDONS.md` — incompatibilidades CUDA).
- Vulkan/Polaris: ver [`3D-RENDERING-TOOLS-RESEARCH.md`](3D-RENDERING-TOOLS-RESEARCH.md) §6 e [`BLENDER-MCP-RESEARCH.md`](BLENDER-MCP-RESEARCH.md) §Fontes.
