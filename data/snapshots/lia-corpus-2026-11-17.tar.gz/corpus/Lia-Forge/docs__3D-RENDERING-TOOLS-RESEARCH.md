# 3D-RENDERING-TOOLS-RESEARCH — Motores, visualizadores e renderização para a Lia Forge

**Data:** 2026-11-14 (UTC) · **Branch:** `arena/6113e868-lia-forge` · **Estado:** RESEARCH / planejamento — **não autoriza implementação, instalação, adoção ou custo**.

**Escopo:** Three.js e react-three-fiber; renderização 3D em interfaces desktop; visualizadores de modelos; câmeras/luzes/materiais/texturas; animação de personagens; GLTF/GLB; renderização de cenas e previews; geração de spritesheets a partir de modelos/animações; limites de GPU/RAM; hardware de referência (RX 580 8 GB, Ryzen 5 5500, 16 GB RAM, Windows).

**Importante — não duplicar pesquisa:** este repositório já contém um pacote profundo de pesquisa de Three.js para a Forge: [`docs/threejs-3d-environment/`](threejs-3d-environment/README.md) (17 documentos: r187, WebGL2, orçamentos de performance, contrato de integração, 76 funcionalidades mapeadas, roadmap de skills). Este documento **não repete** aquele conteúdo; ele avalia o *ecossistema de ferramentas 3D* e as alternativas, e posiciona Three.js dentro dele. Ferramentas de pipeline (gltf-transform, validadores, KTX2) estão em [`ASSET-PIPELINE-TOOLS-RESEARCH.md`](ASSET-PIPELINE-TOOLS-RESEARCH.md); automação Blender em [`BLENDER-MCP-RESEARCH.md`](BLENDER-MCP-RESEARCH.md).

**Convenções:** **F** fato verificado (GitHub API/npm/PyPI/fetch 2026-11-14) · **I** inferência · **H** hipótese.

---

## 1. Resumo executivo

- **F** Three.js `r187.0` (npm `three@0.187.0`, MIT, zero dependências, 2026-10-30) é a escolha tecnicamente coerente com o que a Forge já documentou: consumo de GLB, previews, inspeção, captura de frames. 118,6 mil stars, push 2026-11-16.
- **F** react-three-fiber `v9.8.2` (MIT) é um **renderer React para Three.js**, não um motor: faz sentido apenas se a shell da Forge for React (a T13 usa React em `src/App.jsx`) **e** a equipe preferir declarativo. O acoplamento extra (React 19, reconciler, drei) não é grátis.
- **F** Não há empate prático com Babylon.js (Apache-2.0, full-featured: PBR, particles, GUI, Inspector) e PlayCanvas (MIT, engine + editor SaaS): são **alternativas legítimas** com custo de migração alto e sem benefício claro sobre o trabalho já feito em `docs/threejs-3d-environment/`.
- **F — hardware:** RX 580 8 GB (Polaris/GCN4) roda WebGL2 em qualquer Chromium; **não** tem CUDA nem ROCm; HIP-RT (Blender 5.1) exige ray accelerators (RDNA2+) — irrelevante aqui; Blender em GPU = OpenGL/EEVEE (Vulkan experimental, com ressalvas Polaris/Linux — ver §6). Para previews 3D pesados, o limite prático é a **VRAM de 8 GB** e a CPU Ryzen 5 5500 em renders offline.
- **Spritesheets de modelos 3D:** a rota confiável é **Blender headless → PNG seq → atlas** (determinística, auditável). Three.js consegue o mesmo via captura offscreen (WebGLRenderTarget + readPixels), útil para **previews interativos e turnos de câmera**, com ressalvas de fidelidade de iluminação — detalhes em §5.
- **WebGPU:** `WebGPURenderer` do three ainda é experimental no r187; em Electron/Chromium no Windows funciona via D3D12/Vulkan, mas **não é base de produção**; manter WebGL2 (alinhado a `docs/threejs-3d-environment/09-HARDWARE-E-DESEMPENHO.md`).

## 2. Comparação principal: Three.js × react-three-fiber

| | Three.js (imperativo) | react-three-fiber (declarativo) |
|---|---|---|
| O que é | Engine 3D WebGL2/WebGPU, cena/câmera/materiais/loaders | Renderer customizado React→three; cena como JSX |
| Licença | MIT (zero-dep) | MIT; helpers `@react-three/drei@10.7.9` (MIT, 10,2 mil stars), `gltfjsx` (MIT, **push 2024-11-04** — estagnado) |
| React exigido | Não | **Sim (React 19)** |
| API | `new THREE.Scene()`, loaders, `AnimationMixer` | `<Canvas>`, hooks (`useFrame`), reconciler |
| GLB pipeline | `GLTFLoader` + `KTX2Loader` + `DRACOLoader` + `MeshoptDecoder` | Idem (via three) + `useGLTF` do drei |
| Animação | `AnimationMixer`, `SkinnedMesh`, morph targets | `useAnimations` (mixer por baixo) |
| SSR/Electron | Trivial (sem DOM React necessário) | Trivial em renderer React |
| Bundle | ~600–700 KB min (core; tree-shake parcial) (I) | core + reconciler + react |
| Testabilidade | Alta (sem framework) | Alta (React Testing Library) mas com mocks de WebGL |
| Quando escolher | Viewport próprio da Forge, captura offscreen, headless-ish | Se a UI já é React-pesada e a equipe quer cena declarativa |
| Risco | Baixo | Acoplamento ao ciclo React; drei puxa dezenas de deps transitivas (auditar) |

**Leitura (I):** os dois **não** são substitutos entre si em todas as camadas — r3f **é** three.js por baixo. A pergunta real é "a cena será gerenciada imperativamente pelo módulo Forge ou declarativamente pelo React?". Dado que (a) a Forge quer fronteira de adapter própria e (b) já mapeou r187 APIs em `docs/threejs-3d-environment/03`, o caminho de menor atrito e menor dependência é **three.js direto**, com r3f como **ALTERNATIVE** se a equipe escolher shell React 19 integralmente. Trocar r187→r3f depois é possível (mesmo grafo de objetos), o contrário também.

**Velho conhecido:** `three-stdlib` (community, usado pelo drei/gltfjsx) não foi auditado aqui — se r3f for adotado, auditar transitivas.

## 3. Motores e visualizadores alternativos

| Ferramenta | Licença | Stars · push | Tecnologia | Papel | Classe · P |
|---|---|---|---|---|---|
| **Three.js** `0.187.0` | MIT | 118,6 mil · 2026-11-16 | TS; WebGL2 (WebGPU exp.) | Engine/preview/inspeção | **RECOMMENDED · P0/P1** (decisão já proposta no pacote threejs) |
| **react-three-fiber** `9.8.2` | MIT | 33,8 mil · 2026-10-21 | React renderer | Camada declarativa sobre three | ALTERNATIVE · P2 |
| **Babylon.js** `@babylonjs/core@9.36.0` | Apache-2.0 | 26,4 mil · 2026-11-15 | TS; WebGL2/WebGPU | Engine completo (PBR, partículas, GUI, Inspector) | RESEARCH-ONLY · P3 |
| **PlayCanvas** engine `2.24.1` | MIT | 17,3 mil · 2026-11-16 | JS/WebGPU/WebGL2 | Engine + editor web (SaaS) | RESEARCH-ONLY · P3 |
| **`<model-viewer>`** `@google/model-viewer@4.4.0` | Apache-2.0 | (Google) · 2026-10-09 | Web component | Embed "3D turntable" pronto p/ specs GLB; sem autoria | EXPERIMENTAL · P2/P3 |
| **DonMcCurdy three-gltf-viewer** | MIT | 2,5 mil · 2026-11-02 | three.js | Referência de viewer mínimo; código legível p/ fork | RESEARCH-ONLY (referência) · P3 |
| **three-mesh-bvh** | MIT | 3,6 mil · 2026-11-13 | three addon | Raycast/colisão de milhões de tris | ALTERNATIVE · P2 (se seleção por clique em malha densa) |
| **three.quarks** | MIT | 1,2 mil · 2026-05-21 | three addon | Partículas (API estilo Unity) | RESEARCH-ONLY · P3 |
| **gltfjsx** | MIT | 5,9 mil · **2024-11-04** | CLI GLB→JSX | Só p/ fluxo r3f; estagnado | RESEARCH-ONLY · P3 |

**Por que não Babylon como padrão:** Apache-2.0 ok, mas (a) ecossistema de skills/exemplos Forge já é three; (b) bundle e superfície de API maiores; (c) migração não paga o custo hoje. **Fica documentado como ALTERNATIVE de fuga** caso three encrave num requisito (ex.: física nativa, GUI in-world madura) — decisão humana.

**PlayCanvas:** engine excelente e WebGPU-first, mas o produto real inclui editor/cloud SaaS (custos desconhecidos) — contrário ao princípio de autonomia/local. MIT cobre só o engine.

**model-viewer:** ótimo para "ver GLB com 1 tag" (turntable, AR); **não** serve para inspeção técnica (contagem de tris, morph targets, animações, métricas) — função de prova, não de ferramenta.

## 4. Capacidades exigidas × ferramentas

| Capacidade | Três.js | r3f | Babylon | Notas Forge |
|---|---|---|---|---|
| GLB/GLTF + Draco/KTX2/meshopt | ✅ loaders | ✅ (via three) | ✅ | Transcoders Basis/Draco acompanham o `three` (F) |
| Preview/inspeção de asset | ✅ | ✅ | ✅ | Métricas (draw calls, texturas, VRAM est.) via `renderer.info` (F) |
| Animação de personagem (skeletal/morph) | ✅ AnimationMixer | ✅ useAnimations | ✅ | Retarget entre rigs = problema de **dados**, não de renderer |
| Câmeras/luzes/materiais/texturas | ✅ | ✅ | ✅ (mais prontos) | Lia Scene exigiria módulo próprio — não é "grátis" em nenhum deles |
| Spritesheet a partir de animação | ⚠️ via captura | ⚠️ idem | ✅ (I: via RTT) | Rota de produção recomendada: **Blender headless** (§5) |
| Editor de cenas completo | ❌ (só exemplos) | ❌ | ⚠️ Inspector (I) | Todos exigiriam construir a UI — ver [`threejs-3d-environment/10-IMPORTACAO-E-EXPORTACAO.md`](threejs-3d-environment/10-IMPORTACAO-E-EXPORTACAO.md) e [`05-ARQUITETURA-PROPOSTA.md`](threejs-3d-environment/05-ARQUITETURA-PROPOSTA.md) |
| Física | ❌ (addon: ammo/cannon) | ❌ idem | ✅ Havok plugin | Fora de escopo atual |
| Export glTF de volta | ⚠️ GLTFExporter (sem KTX2; `KTX2Exporter` separado — ver `threejs-3d-environment/10`) | ⚠️ idem | ✅ | Exportação não é portão de QA da Forge — Blender é |

## 5. Gerar spritesheets a partir de modelos/animações — viabilidade

**Sequência de referência (Blender headless, rota principal):**

1. GLB aprovado entra no staging do projeto.
2. Script first-party (`blender --background --python …`, sem rede, sem LLM) abre o GLB, aplica action/NLA configurada, orto_camera fixa, fundo transparente (`film_transparent`), resolução/margem configuráveis.
3. Render EEVEE (rápido; Polaris ok por OpenGL) → PNG sequence com alpha.
4. Empacotamento: `free-tex-packer` (MIT) CLI/core **ou** empacotador first-party (recomendado p/ contrato/ledger) → atlas + JSON (formatos Pixi/Phaser/JSON hash).
5. QA: validadores próprios (dimensões, alpha, naming, perfil de destino) → envelope de proveniência → revisão humana.

**Caminho three.js (previews e ferramentas auxiliares):** `WebGLRenderTarget` + cena ortográfica + `readRenderTargetPixels` por frame → ImageBitmap → encoder PNG (ex.: `UPNG`/canvas.toBlob) → mesmo empacotador. **F** viável tecnicamente; **I** limitações: (a) resultado depende de iluminação/tonemapping do renderer (fidelidade ≠ Blender); (b) antialiasing/SSAA custa GPU; (c) captura fora de tela em Electron ok; (d) **não** substitui EEVEE para "render de verdade" com sombras/SSAO/misturadores pesados.

**Quando usar three.js p/ sprites:** iterar rapidamente (rotações, contagens, previews de atlas), não para arte final crítica. A T13 já decide que o Blender é o produtor; three.js é o **inspetor**.

**Remotion como compositor** entra pós-spritesheet (vídeos de showcase) — ver [`ASSET-PIPELINE-TOOLS-RESEARCH.md`](ASSET-PIPELINE-TOOLS-RESEARCH.md) §6.

## 6. Hardware de referência — limites reais (RX 580 8 GB · Ryzen 5 5500 · 16 GB · Windows)

| Tópico | Fato/estimativa | Base |
|---|---|---|
| WebGL2 em Electron (Chromium→ANGLE D3D11/Vulkan) | ✅ suportado; RX 580 roda cenas de personagem (≤ 100–200 MB VRAM) com folga | **F** (geral); benchmark não executado nesta missão |
| VRAM 8 GB | Limite para texturas 4K×muitos mapas + sombras; preferir 2K e KTX2/Basis (menor pico de memória GPU; transcoder necessário) | **I** |
| FP16 half rate | Polaris FP16 2× FP32 — ok para shaders modernos | **I** |
| WebGPU | Chromium/Windows: via D3D12/Vulkan; drivers AMD Polaris com Vulkan existiram (ver matriz Blender abaixo), mas three r187 WebGPU = **experimental**; não base de produção | **F** (three manual) + **I** |
| Vulkan (Blender 5.x) | Tabela oficial do projeto (fev/2026) lista RX 400–600 como "AMD Official/latest" no Windows; no Linux Polaris crashava (3D cursor); backend ainda experimental; EEVEE+shadows/luzes limitados | **F** (web_search: Blender/Phoronix/digitalproduction) |
| Cycles GPU (HIP/HIP-RT) | **Sem ray accelerators no Polaris; Cycles cai para CPU** (Ryzen 5 5500 = lento; cenas simples apenas). EEVEE é o caminho de prévia | **I** (Phoronix sobre HIP-RT no 5.1) |
| RAM 16 GB | Suficiente p/ viewer + Electron + Blender headless serializado; **não** rodar Blender render + Electron pesado + ComfyUI juntos | **I** |
| CUDA/ROCm | Ausentes para esta placa (confirmado em pesquisa anterior desta série); nenhum fluxo deve assumir | **F** (auditorias anteriores do repo) |

**Implicação:** arquitetura alvo = **render local leve** (EEVEE/CPU) + **preview interativo WebGL2** + **nenhuma etapa dependente de CUDA/ROCm/HIP-RT**. ComfyUI/geração local de imagem **não** entra no caminho crítico (ver auditorias anteriores).

## 7. Integração com a arquitetura Forge

Seguindo os princípios já estabelecidos (interface própria; adapters/providers; contratos; MCP/agentes opcionais; downloads sob demanda):

```
┌──────────────────────────────────────────────┐
│ Lia Forge UI (Electron)                       │
│  └─ Módulo Lia3DSprite / Viewport (PROPOSED)  │
│       └─ Adapter: three-inspection@r187       │  ← contrato próprio; zero React obrigatório
│            GLB in → métricas + turntable PNG  │
└──────────────▲─────────────────▲─────────────┘
               │ GLB             │ PNG/metrics (sinais p/ QA)
┌──────────────┴─────────────────┴─────────────┐
│ Blender headless (bpy first-party)            │  ← produtor de sprites/bakes
└──────────────────────────────────────────────┘
```

- **Nenhum** dos motores deve vazar API para o domínio: os adapters expõem `inspect/preview/render-frame/metrics`, não `THREE.Scene`.
- **Three.js e Blender não se substituem**: inspeção ≠ autoria. Ver fronteiras em `docs/threejs-3d-environment/05` e `06` e [`BLENDER-BRIDGE-SPECIFICATION.md`](BLENDER-BRIDGE-SPECIFICATION.md).
- **Provider remoto de 3D (AI gen)** permanece desligado por padrão (ver [`BLENDER-MCP-RESEARCH.md`](BLENDER-MCP-RESEARCH.md) §6).

## 8. Lacunas e riscos

1. **H** Performance real de WebGL2 em Electron + RX 580 para cenas GLB típicas de jogo **não medida** — exige benchmark autorizado (criar corpus de 3 GLBs representativos).
2. **I** Captura offscreen em Electron precisa tratar perda de contexto (`webglcontextlost`) — detalhe não medido; usar `WebGLRenderTarget` single-sample + supersampling por resolução.
3. r3f/drei **não auditados** (transitivas, licenças) — bloqueio se a rota r3f for escolhida.
4. Exportadores three (GLTFExporter/KTX2Exporter) **não** são portão de qualidade; não confundir "preview ok" com "asset aprovado".
5. **WebGPU/Vulkan** no hardware de referência: tratar como experimental até validação on-target.

## 9. Classificação consolidada

| Ferramenta | Classe | P |
|---|---|---|
| Three.js r187 (WebGL2) | RECOMMENDED (como módulo de inspeção; adoção requer decisão humana — já PROPOSED no repo) | P0→P1 |
| react-three-fiber + drei | ALTERNATIVE | P2 |
| `<model-viewer>` | EXPERIMENTAL | P2/P3 |
| three-mesh-bvh | ALTERNATIVE | P2 |
| three.quarks | RESEARCH-ONLY | P3 |
| Babylon.js | RESEARCH-ONLY | P3 |
| PlayCanvas engine | RESEARCH-ONLY | P3 |
| gltfjsx / gltf viewer (DonMcCurdy) | RESEARCH-ONLY (referência) | P3 |

## 10. Fontes

- GitHub API (2026-11-14): `mrdoob/three.js`, `pmndrs/react-three-fiber`, `pmndrs/drei`, `pmndrs/gltfjsx`, `BabylonJS/Babylon.js`, `playcanvas/engine`, `GoogleChrome/model-viewer` (npm `@google/model-viewer`), `DonMcCurdy/three-gltf-viewer`, `gkjohnson/three-mesh-bvh`, `Alchemist0823/three.quarks`.
- npm registry (2026-11-14): `three@0.187.0`, `@react-three/fiber@9.8.2`, `@react-three/drei@10.7.9`, `@babylonjs/core@9.36.0`, `playcanvas@2.24.1`, `@google/model-viewer@4.4.0`.
- Repositório: `docs/threejs-3d-environment/` (pesquisa profunda já existente — r187, WebGL2, hardware, skills), `docs/BLENDER-BRIDGE-SPECIFICATION.md`, `docs/auditoria-blender-local/`, `docs/AGENT-SKILLS-MCP-IMPLEMENTATION-ASSESSMENT.md`.
- Hardware/Vulkan: Blender Lab page (fetch 2026-11-14), Phoronix "Blender 5.1 Released… HIP-RT" (2026-03-17), tabela de plataformas Vulkan do projeto Blender (fev/2026) via digitalproduction.com.
