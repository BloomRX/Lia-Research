# Lia Agent Hub

**Plataforma independente para criar, descobrir, validar, organizar, versionar, empacotar e distribuir capacidades para agentes de IA.**

> **Estado atual: MVP implementado e testado.** Fase 0 e Fase 0.1 concluídas;
> Fase 1 (implementação do MVP) executada nesta rodada. 214 testes automatizados
> passando. Ver [docs/MVP-GUIA.md](docs/MVP-GUIA.md) para instalar e usar e
> [docs/DESENVOLVIMENTO.md](docs/DESENVOLVIMENTO.md) para desenvolver e
> [docs/MVP-RELATORIO-FINAL.md](docs/MVP-RELATORIO-FINAL.md) para o relatório
> honesto do que foi e não foi validado.

O Lia Agent Hub é um produto de escopo transversal: deve atender Game Development, programação, arte e design, pesquisa, produtividade, automação, mídia, lazer e outros domínios que utilizem agentes compatíveis.

## O que a Fase 0 concluiu

O Hub **é** viável como aplicação independente — com um escopo mais estreito do que a visão inicial sugeria:

> O Hub registra capacidades: dá a elas **identidade, origem, versão, licença, avaliação de risco e forma de pacote**. Ele **não** as executa, não as autoriza, não guarda credenciais e não orquestra nada.

A auditoria encontrou **oito lacunas** que nenhum dos produtos Lia atende hoje — registro de proveniência, pipeline de intake, formato de pacote portátil, análise de licença, contrato de distribuição, detecção de conteúdo malicioso em prosa, versionamento de capacidade e catálogo de MCP. **Nenhuma exige executar código.**

## O que está pronto e o que não está

### Concluído (documentação)

- [x] Auditoria de 4 repositórios, 30 branches e ~40 módulos, com commit exato
- [x] Pesquisa de 7 candidatas externas com licença, egress e decisão
- [x] Fronteiras de produto e arquitetura em 5 camadas
- [x] Modelo de dados de capacidade e formato de pacote `.lia-capability`
- [x] Modelo de segurança com 10 classes de ameaça e 7 riscos residuais declarados
- [x] Armazenamento, portabilidade e backup
- [x] Comparação de plataforma com 8 critérios ponderados
- [x] MVP de 8 capacidades e roadmap em 6 fases
- [x] 27 decisões registradas com recomendação — **0 aprovadas**
- [x] Revisão de consistência (Fase 0.1): piso de Python corrigido, política Unicode por categoria, terminologia de integridade, exportação por destino

### Implementado (MVP)

- [x] Aplicação desktop local com interface web embarcada (7 módulos de domínio,
      6 adaptadores, servidor local com token de sessão)
- [x] Biblioteca com busca e filtros por tipo, confiança e tag
- [x] Importação de arquivo, pasta, `.zip` e `.lia-capability`, com quarentena
      obrigatória e promoção explícita
- [x] Validação estrutural de `SKILL.md` e política Unicode por região
- [x] Procedência, licença (presença ≠ permissão) e risco por regras explícitas
- [x] SHA-256 por arquivo e de árvore; deduplicação por conteúdo
- [x] Exportação `.lia-capability` com verificação de adulteração
- [x] `index.json` portátil, validável, sem segredos
- [x] 258 testes: funcional, segurança, persistência e interface
- [x] Build configurado para Windows via PyInstaller
- [ ] **Executável Windows gerado e testado** — não validado neste ambiente
      (sem Windows nem WebView2); o script de build roda testes e aborta se
      algum falhar
- [ ] **Licença do repositório** — D-16 aberta, aguarda decisão humana
- [ ] **Nenhuma alteração** em Lia Studio, Lia Forge ou Lia Project

## Fronteira dos produtos

| Produto | É dono de | Não faz |
|---|---|---|
| **Lia Agent Hub** | Identidade, proveniência, licença, confiança, validação estrutural, versionamento, empacotamento, distribuição | Executar, autorizar, guardar credencial, orquestrar, produzir asset |
| **Lia Studio** | Sessão, contexto de desenvolvimento, permissões, aprovações, execução de agentes, QA de jogo | Ser o dono exclusivo da biblioteca de capacidades |
| **Lia Forge** | Providers, modelos, pesos, workflows, pipelines, validação técnica de assets | Catalogar capacidades genéricas |

**A única integração entre o Hub e os demais é arquivo em disco.** Não há runtime, não há API obrigatória, não há serviço residente. Se o Hub for desinstalado, os hosts continuam funcionando.

## Princípios

Independência, portabilidade, local-first, neutralidade de providers, controle humano, **segurança por padrão**, separação entre autoria e execução, rastreabilidade e extensibilidade.

Três que merecem destaque porque a pesquisa mostrou que são fáceis de perder:

1. **Nada é executado no MVP.** Sem sandbox comprovado em Windows, prometer "testado" seria alegação falsa.
2. **Confiança é decisão humana registrada**, não score. Scanner verde produz evidência, nunca aprovação.
3. **Nenhum segredo tem lugar no schema.** `secrets.envVars` aceita apenas nomes de variáveis.
4. **Integridade não é assinatura.** O Hub verifica hashes; não assina nada. "Índice assinado" é vocabulário proibido até existir assinatura de verdade.
5. **Privado e público não são a mesma operação.** Backup local nunca é bloqueado; redistribuição pública exige direitos comprovados.

## Documentação

### Research
- [Auditoria de repositórios e branches](docs/research/REPOSITORY-AND-BRANCH-AUDIT.md)
- [Candidatos de integração e pesquisa externa](docs/research/INTEGRATION-CANDIDATES.md)
- [Revisão de consistência da Fase 0.1](docs/research/PHASE-0-1-CONSISTENCY-REVIEW.md)

### Architecture
- [Fronteiras de produto, arquitetura e modelo de dados](docs/architecture/PRODUCT-BOUNDARIES-AND-ARCHITECTURE.md)
- [Modelo de segurança e confiança](docs/architecture/SECURITY-AND-TRUST-MODEL.md)
- [Dados, armazenamento e portabilidade](docs/architecture/DATA-STORAGE-AND-PORTABILITY.md)

### Product
- [Plataforma e stack](docs/product/PLATFORM-AND-TECHNOLOGY-DECISION.md)
- [MVP e roadmap](docs/product/MVP-AND-ROADMAP.md)

### Governança
- [Relatório final da Fase 0](docs/PHASE-0-FINAL-REPORT.md)
- [Registro de decisões](docs/DECISION-REGISTER.md)
- [Visão de produto e direção arquitetural](docs/PRODUCT-VISION.md)
- [Mandato de pesquisa da Fase 0](docs/PHASE-0-ARENA-BRIEF.md)
- [Fluxo de branches e releases](docs/BRANCH-AND-RELEASE-FLOW.md)
- [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md) — nenhum código de terceiros incorporado
- [`.gitignore`](.gitignore) — higiene adaptada do kit Lia

## Próximo passo

A Fase 1 depende de quatro decisões humanas (`D-13` escopo do MVP, `D-14` stack, `D-03` formato, `D-06` armazenamento) e de uma quinta que pode correr em paralelo: pesquisa de isolamento em Windows (`D-05`/`D-18`), que determina se o produto terá Test Lab algum dia.

`D-16` — a **licença deste repositório** — continua aberta e é decisão humana. O `LICENSE` **não** foi criado, de propósito.

A implementação só começa após revisão humana e aprovação explícita da especificação resultante.

Consulte também [AGENTS.md](AGENTS.md) para as regras deste repositório, inclusive a distinção obrigatória entre `IMPLEMENTED`, `EXECUTED`, `VALIDATED`, `PROPOSED`, `PLANNED`, `RESEARCH` e `UNKNOWN`.
