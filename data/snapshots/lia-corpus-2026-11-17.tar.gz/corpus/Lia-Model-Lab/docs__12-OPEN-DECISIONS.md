# 12 — Decisões abertas, impedimentos e riscos

**Missão 001 · consulta: 2026-10-30 · estado: proposta para revisão.**

## Registro: tudo abaixo é PROPOSTO ou PENDENTE

Princípios válidos da fundação foram incorporados ao ADR-0001; não há aprovação nova de modelos, custos, dados ou publicação. O proprietário aprova produto, persona, custo, direitos e release. Responsável técnico futuro propõe experimentos com evidências.

| ID | Decisão / risco | Evidência atual | Próxima prova / condição de resolução |
|---|---|---|---|
| O-01 | Core 4B inicial vs 27B remoto | Ranking por viabilidade, sem benchmark | Gates licença/compatibilidade, pt-BR/tools e custo, ADR proprietário |
| O-02 | Revisão exata de pesos/templates/formatos | Cards consultados, sem manifest de pesos | Congelar commits/hashes por checkpoint antes de download |
| O-03 | Licenças atuais e derivados | Gemma 4 Apache confirmado documentalmente; especialistas/vozes ainda incompletos | Snapshot LICENSE/NOTICE de cada artefato/dataset e revisão de distribuição |
| O-04 | GPU local 4/8 GB e ROCm/Vulkan | Registros históricos divergentes; sandbox sem GPU | Diagnóstico no PC; não inferir de nome da placa |
| O-05 | Backend de treino/framework | Compatibilidade documental, não smoke-tested | Load/backward/save/reload/merge/export na versão exata e GPU suportada |
| O-06 | Primeira voz Lia / biometria | Modelos existentes, identidade/direitos indefinidos | Voz original/consentida, contrato de uso e teste pt-BR; nada de clonagem sem autorização |
| O-07 | Persona canônica e humor | Objetivos, sem canon detalhado aprovado | Profile e rubrica revisados; dataset não pode inventar identidade |
| O-08 | Memória store / embeddings / retenção | AIRI fatos existe, pgvector placeholder | Schema ACL+temporal, retrieval local, forget/restore e provedor de storage |
| O-09 | Discord e privacidade entre cenas | AIRI ADR declara live checks faltantes e compartilhamento de contexto | Isolamento por scope e saída, consentimento de voz, testes multiusuário |
| O-10 | Minecraft primeiro, adapter e servidor | Quatro camadas presentes upstream; não executadas | Servidor autorizado, versões/licenças, seeds e action schema; aceitar escolha de jogo |
| O-11 | Factorio integração ausente | UI/store sem agente pronto comprovado | Prova server-side state/action e benchmark de produção |
| O-12 | Dados/escala/custo de curadoria | Plano apenas | Data cards e consentimentos, test selado e revisão humana |
| O-13 | Thresholds e amostra | Propostas, sem base/poder medidos | Congelar protocolo antes do treino; inconclusivo não é PASS |
| O-14 | Quantizações/backend visual/áudio | Não testados | Comparar base/adaptado/quant, round-trip e projector/talker |
| O-15 | Persistência/limites Arena e job remoto | Snapshot de recursos, sem SLA | Verificar quotas/duração/storage e recovery fora da sessão |
| O-16 | MoE/Omni/representações compartilhadas | Hipóteses de longo prazo | Ablação de routing/composição, custo/qualidade e vantagem de consolidação |

## Impedimentos para começar treinamento agora

Não há base revision fechada, dataset de produção aprovado, test selado/baseline medido, GPU/custo aprovado nem probe de treinamento/PEFT reload. São bloqueios explícitos; não defeitos escondidos por um ranking. Esta missão prepara a execução, não autoriza a próxima fase.

## Riscos e mitigação

Esquecimento/persona repetitiva → mistura e ablação; alucinação de ação → retorno verificável; reward hacking → métricas de estado e holdout; prompt injection → ACL/sandbox determinísticos; roubo/vazamento de memória → isolamento antes de retrieval; voz sem direitos → consent ledger; licença mutável → snapshots; dependência CUDA → contratos e fallback CPU/Vulkan; arquitetura excessiva → poucos pesos e etapas; base enorme → envelope medido; contaminação → split por grupo/hash; afirmação de maturidade → status de evidência explícito.

Revisitar pesquisa upstream no início de Gate 0 e a cada release. Novos lançamentos não invalidam automaticamente baselines nem autorizam troca de base. A fundação offline foi implementada; não confundir com implementação do runtime da aplicação.

## Atualização — infraestrutura de inferência

Supervisor/worker local e contratos de renderização implementados em [16](16-REAL-INFERENCE-PILOT.md). O-01: 0.8B para smoke, 4B para capacidade; sem aprovação de base. O-02: ainda sem revision/bytes exatos dos checkpoints. O-04: ambiente da sessão ~4 GB RAM, sem nós GPU; isso não descreve o PC do proprietário. O-05: runtime Torch/Transformers não instalado/testado, PEFT e QLoRA continuam sem probe. Nenhuma dessas pendências foi encerrada por testes de fixtures.

Hardening atual: registries/AutoConfig/API de máscaras TF5.22.1 testados sem Torch. O-02/O-05 não encerrados: arquivos originais e inferência/PEFT ainda ausentes. String de referência foi removida da execução em favor de grant operacional humano externo, uso único; isso não autentica identidade. Perfis Linux CPU limitam recursos/IP quando explicitamente aplicados; não são proteção equivalente em outros OS/GPU.

## Decisões LFM3 — 2026-10-31

- Adicionar sete originais e seis GGUF como pesquisa; não adicionar backend executável nem mudar allowlist de licença. [Relatório e gates](17-LFM3-RESEARCH.md).
- Priorizar comparações separadas: Core pós-treinado, Base como ablação, VL, Audio, Omni condicional e decisões d1; nenhuma escolha final.
- Bloqueios: LICENSE/NOTICE individuais, entidade/Threshold comercial, revisions/config/listing exatos, auditoria de código/deps/codec ou vendorização aprovada, runtime e hardware reais.
- GGUF/llama.cpp é hipótese inicial de rota local; falta protocolo autorizado por formato/ação/auxiliares. d1 demanda contrato de decisão próprio; não usar worker generativo atual.
- Adaptação SFT/LoRA documentada pelo fabricante, QLoRA e preservação/reload ainda desconhecidos. Qualquer probe com pesos ou treino requer missão/autorização separada.
